#!/bin/bash
export PATH=$HOME/bin:$PATH KUBECONFIG=$HOME/.kube/config
K="sudo -n /var/lib/rancher/rke2/bin/kubectl --kubeconfig /etc/rancher/rke2/rke2.yaml"
NS=llm-d-pd-disaggregation; LB=http://192.0.2.10:11111; IP=192.0.2.10; MODEL=Qwen/Qwen3-32B-FP8; PORT=8080
EPP_IP=$($K -n $NS get svc pd-disaggregation-epp -o jsonpath='{.spec.clusterIP}')
mapfile -t KV < <($K -n $NS get pods -l llm-d.ai/role=aggregated --field-selector status.phase=Running -o jsonpath='{range .items[*]}{.metadata.name}={.status.podIP}{"\n"}{end}')
declare -A NAME2IP; PODIPS=(); for kv in "${KV[@]}"; do NAME2IP[${kv%=*}]=${kv#*=}; PODIPS+=(${kv#*=}); done
EPS=""; for ip in "${PODIPS[@]}"; do EPS="$EPS${EPS:+,}{\"endpointIP\":\"$ip\",\"targetPort\":8000,\"weight\":1}"; done
curl -s -X DELETE "$LB/netlox/v1/config/loadbalancer/externalipaddress/$IP/port/$PORT/protocol/tcp">/dev/null
curl -s -X POST $LB/netlox/v1/config/loadbalancer -H 'Content-Type: application/json' -d "{\"serviceArguments\":{\"externalIP\":\"$IP\",\"port\":$PORT,\"protocol\":\"tcp\",\"mode\":4,\"sel\":0,\"name\":\"vrfy-epp\",\"eppEndpoint\":\"$EPP_IP:9002\",\"eppFailureMode\":\"FailOpen\",\"eppTimeoutMs\":3000},\"endpoints\":[$EPS]}">/dev/null
sleep 2
ms(){ date +%s%3N; }
LOG=~/p5.log; : > $LOG; rm -f ~/p5.stop
# continuous load (sequential ~ as fast as it answers), logs: epoch code time servedpodlog
( while [ ! -f ~/p5.stop ]; do t=$(ms); r=$(curl -s -o /dev/null -m 15 -w '%{http_code} %{time_total}' -X POST http://$IP:$PORT/v1/completions -H 'Content-Type: application/json' -d "{\"model\":\"$MODEL\",\"prompt\":\"p5 $t uniq$RANDOM: a color.\",\"max_tokens\":8}"); echo "$t $r" >> $LOG; done ) &
LOOP=$!
mark(){ echo ">>> $(ms) $*"; }
sleep 4
# victim = first pod
VN=${KV[0]%=*}; VIP=${KV[0]#*=}; echo "victim pod: $VN ($VIP)"
mark "5a T_DELETE force delete $VN"; $K -n $NS delete pod $VN --grace-period=0 --force >/dev/null 2>&1
sleep 25
mark "5a_done"; 
# wait for a new victim to be Running for subsequent cases
sleep 20
mapfile -t KV2 < <($K -n $NS get pods -l llm-d.ai/role=aggregated --field-selector status.phase=Running -o jsonpath='{range .items[*]}{.metadata.name}={.status.podIP}{"\n"}{end}')
VN2=${KV2[0]%=*}; VIP2=${KV2[0]#*=}
mark "5c T_HANG SIGSTOP vLLM in $VN2 ($VIP2)"; $K -n $NS exec $VN2 -c vllm -- bash -c 'kill -STOP $(pgrep -f "vllm" | head -1)' >/dev/null 2>&1
sleep 25; mark "5c T_CONT resume"; $K -n $NS exec $VN2 -c vllm -- bash -c 'kill -CONT $(pgrep -f "vllm" | head -1)' >/dev/null 2>&1
sleep 10; mark "5c_done"
touch ~/p5.stop; wait $LOOP 2>/dev/null; rm -f ~/p5.stop
echo "### LOG saved ($(wc -l < $LOG) reqs). codes: $(awk '{print $2}' $LOG | sort | uniq -c | tr '\n' ' ')"
echo "### slow/errors (>1s or non-200):"; awk '$2!=200 || $3>1.0 {print}' $LOG | head -30
echo "PHASE5 DONE $(date -u +%T)"
