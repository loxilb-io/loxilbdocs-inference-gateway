#!/bin/bash
# Q3 combined: 같은 대화 한 건에서 (a)턴별 캐시 히트 (b)EPP 후보 축소 3->1 (c)선택 endpoint 를 함께 캡처. EPP는 이미 v=4 가정.
set -u
K="sudo -n /var/lib/rancher/rke2/bin/kubectl --kubeconfig /etc/rancher/rke2/rke2.yaml"
NS=llm-d-pd-disaggregation; LB=http://192.0.2.10:11111; IP=192.0.2.10; PORT=8080; MODEL=Qwen/Qwen3-32B-FP8
EPOD=$($K -n $NS get pods -o name | grep pd-disaggregation-epp | head -1)
mapfile -t KV < <($K -n $NS get pods -l llm-d.ai/role=aggregated --field-selector status.phase=Running -o jsonpath='{range .items[*]}{.status.podIP}{"\n"}{end}')
P1=${KV[0]} P2=${KV[1]} P3=${KV[2]}; echo "pods: $P1 $P2 $P3 ; epp=$EPOD"
EPP_IP=$($K -n $NS get svc pd-disaggregation-epp -o jsonpath='{.spec.clusterIP}')
EPS="{\"endpointIP\":\"$P1\",\"targetPort\":8000,\"weight\":1},{\"endpointIP\":\"$P2\",\"targetPort\":8000,\"weight\":1},{\"endpointIP\":\"$P3\",\"targetPort\":8000,\"weight\":1}"
curl -s -X DELETE "$LB/netlox/v1/config/loadbalancer/externalipaddress/$IP/port/$PORT/protocol/tcp" >/dev/null
curl -s -X POST $LB/netlox/v1/config/loadbalancer -H 'Content-Type: application/json' -d "{\"serviceArguments\":{\"externalIP\":\"$IP\",\"port\":$PORT,\"protocol\":\"tcp\",\"mode\":4,\"sel\":0,\"name\":\"vrfy-epp\",\"eppEndpoint\":\"$EPP_IP:9002\",\"eppFailureMode\":\"FailClose\",\"eppTimeoutMs\":5000},\"endpoints\":[$EPS]}" >/dev/null
sleep 2
q(){ curl -s -m5 http://$1:8000/metrics 2>/dev/null | awk -v k=$2 '$0 ~ "^"k{s+=$NF}END{print s+0}'; }
snap(){ for ip in $P1 $P2 $P3; do echo "$ip $(q $ip vllm:request_success_total) $(q $ip vllm:prefix_cache_queries_total) $(q $ip vllm:prefix_cache_hits_total)"; done; }
whoserved(){ local bf=$1; while read ip s0 qq0 h0; do s1=$(q $ip vllm:request_success_total); if [ "$s1" -gt "$s0" ]; then qq1=$(q $ip vllm:prefix_cache_queries_total); h1=$(q $ip vllm:prefix_cache_hits_total); echo "$ip $((qq1-qq0)) $((h1-h0))"; return; fi; done < "$bf"; echo "? 0 0"; }
NONCE="$RANDOM$RANDOM"; DOC="SESSION-$NONCE. "; for i in $(seq 1 200); do DOC+="In area $NONCE agent $i reviewed record $i about subject $((i*7%13)) detail $((i*3)). "; done
CONV="$DOC"; START=$(date -u +%Y-%m-%dT%H:%M:%SZ)
for t in 1 2 3 4 5; do
  rid="f$NONCE-t0$t"; CONV+=$'\n'"Q$t: one word, color $t."
  snap > ~/.sb
  curl -s -o /dev/null -m 60 -X POST http://$IP:$PORT/v1/completions -H 'Content-Type: application/json' -H "x-request-id: $rid" \
    --data-binary "$(python3 -c "import json,sys;print(json.dumps({'model':'$MODEL','prompt':sys.stdin.read(),'max_tokens':16,'temperature':0}))" <<<"$CONV")"
  read sip dq dh < <(whoserved ~/.sb); hr=$(python3 -c "print('%.1f%%'%(100*$dh/$dq) if $dq else 'n/a')")
  echo "RESULT t$t served=$sip cache_queries=$dq cache_hits=$dh hit=$hr rid=$rid"
  sleep 2
done
sleep 3
echo "=== EPP: 턴별 후보수(num-of-candidates) + 선택 endpoint ==="
$K -n $NS logs $EPOD -c epp --since-time=$START 2>/dev/null | grep "f$NONCE" | python3 - <<'PY'
import sys,json,collections
cand={}; ep={}
for l in sys.stdin:
    try:d=json.loads(l)
    except:continue
    rid=d.get("x-request-id",""); b=d.get("body","")
    if b=="Selecting endpoints from candidates sorted by max score": cand[rid]=d.get("num-of-candidates")
    if b=="Request handled": ep[rid]=d.get("endpoint")
for rid in sorted(set(list(cand)+list(ep))):
    print(f'{rid}  후보수={cand.get(rid)}  선택endpoint={ep.get(rid)}')
PY
echo "=== loxilb [EPP] -> ip (이 대화) ==="
$K -n kube-system logs ds/loxilb-lb --since-time=$START 2>/dev/null | grep -E '\[EPP\].*-> ' | grep -oE '\-> [0-9.]+:' | sort | uniq -c
echo "NONCE=$NONCE"
echo "== RESTORE EPP v=2 + delete rule =="
CUR=$($K -n $NS get deploy pd-disaggregation-epp -o jsonpath='{.spec.template.spec.containers[1].args}')
REST=$(python3 -c "import json,sys;a=json.loads(sys.argv[1]);a=[('--v=2' if x.startswith('--v=') else x) for x in a];print(json.dumps(a))" "$CUR")
$K -n $NS patch deploy pd-disaggregation-epp --type=json -p "[{\"op\":\"replace\",\"path\":\"/spec/template/spec/containers/1/args\",\"value\":$REST}]" >/dev/null
curl -s -X DELETE "$LB/netlox/v1/config/loadbalancer/externalipaddress/$IP/port/$PORT/protocol/tcp" >/dev/null
$K -n $NS rollout status deploy/pd-disaggregation-epp --timeout=180s
echo "FINAL DONE"
