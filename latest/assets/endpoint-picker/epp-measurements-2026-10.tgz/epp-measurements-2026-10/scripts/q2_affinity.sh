#!/usr/bin/env bash
# Q2 (kube-loxilb 호환) — 풀을 건드리지 않고 "결정 주체가 EPP"를 증명.
# 같은 대화(세션)의 연속 턴을 순차로 보냈을 때:
#   loxilb 단독(RR)  → 턴이 여러 파드로 흩어짐(세션당 파드 수 > 1)
#   EPP 켬           → 프리픽스 어피니티로 한 파드에 고정(세션당 파드 수 = 1)
# loxilb의 RR 성향을 EPP가 덮어쓰므로 결정 주체는 EPP.
set -u
K="sudo -n /var/lib/rancher/rke2/bin/kubectl --kubeconfig /etc/rancher/rke2/rke2.yaml"
NS=llm-d-pd-disaggregation; VIP=192.0.2.11; API=http://$VIP:11111/netlox/v1; PORT=8088
MODEL=Qwen/Qwen3-32B-FP8; SESS=${SESS:-6}; TURNS=${TURNS:-8}
OUT=${OUT:-$HOME/repro_out}; mkdir -p "$OUT"
ready_pods(){ $K -n $NS get pods -l llm-d.ai/role=aggregated -o json 2>/dev/null | python3 -c '
import sys,json
for p in json.load(sys.stdin)["items"]:
    cs=p["status"].get("containerStatuses",[])
    if p["status"]["phase"]=="Running" and cs and all(c.get("ready") for c in cs): print(p["status"]["podIP"])'; }
mapfile -t IPS < <(ready_pods); echo "Ready 파드: ${IPS[*]}"
[ ${#IPS[@]} -lt 2 ] && { echo "2파드 미만 → 중단(이 테스트는 분산 대비가 필요)"; exit 1; }
EPP_IP=$($K -n $NS get svc pd-disaggregation-epp -o jsonpath='{.spec.clusterIP}')
EPS=""; for ip in "${IPS[@]}"; do EPS="$EPS${EPS:+,}{\"endpointIP\":\"$ip\",\"targetPort\":8000,\"weight\":1}"; done
vsucc(){ curl -s -m5 http://$1:8000/metrics 2>/dev/null | awk '/^vllm:request_success_total[ {]/{s+=$NF}END{print s+0}'; }
served(){ local -a b=("$@"); local t i; for t in $(seq 1 30); do for i in "${!IPS[@]}"; do
    [ "$(vsucc ${IPS[$i]})" -gt "${b[$i]}" ] && { echo "${IPS[$i]}"; return; }; done; sleep 0.3; done; echo "-"; }
mkrule(){ local mode=$1 sel epp
  case $mode in epp) sel=0; epp=",\"eppEndpoint\":\"$EPP_IP:9002\",\"eppFailureMode\":\"FailClose\",\"eppTimeoutMs\":5000";; rr) sel=0; epp="";; esac
  curl -s -X DELETE "$API/config/loadbalancer/externalipaddress/$VIP/port/$PORT/protocol/tcp" >/dev/null
  curl -s -X POST $API/config/loadbalancer -H 'Content-Type: application/json' \
    -d "{\"serviceArguments\":{\"externalIP\":\"$VIP\",\"port\":$PORT,\"protocol\":\"tcp\",\"mode\":4,\"sel\":$sel,\"name\":\"q2aff\"$epp},\"endpoints\":[$EPS]}" >/dev/null; sleep 2; }
WORDS="gateway router cache prefix block hash tensor kernel latency cluster endpoint session context window attention decode prefill schedule batch token memory replica scorer affinity queue stream header socket proxy metric event worker policy threshold warmup shard rank device module vector matrix layer embedding sampler prompt answer system assistant dialogue history summary document paragraph sentence"
RES=$OUT/q2aff_rows.txt; : > "$RES"
run_mode(){ local mode=$1; mkrule "$mode"; local nonce=$RANDOM
  for s in $(seq 1 $SESS); do
    local pre="Session $mode-$nonce-$s context: $WORDS $WORDS $WORDS ($mode-$nonce-$s)."; local hist=""
    for t in $(seq 1 $TURNS); do
      local -a b; local i; for i in "${!IPS[@]}"; do b[$i]=$(vsucc ${IPS[$i]}); done
      local prompt="$pre$hist Q$t: in one word, color $t? A:"
      curl -s -o /dev/null -m 30 -X POST http://$VIP:$PORT/v1/completions -H 'Content-Type: application/json' \
        -H "x-request-id: q2aff-$mode-$s-$t" -d "$(python3 -c "import json,sys;print(json.dumps({'model':'$MODEL','prompt':sys.stdin.read(),'max_tokens':6}))" <<<"$prompt")"
      local pod; pod=$(served "${b[@]}"); hist="$hist Q$t A$t."
      echo "$mode $s $t $pod" >> "$RES"
    done
  done; }
echo "=== baseline: loxilb 단독(RR) ==="; run_mode rr
echo "=== EPP 켬 ==="; run_mode epp
curl -s -X DELETE "$API/config/loadbalancer/externalipaddress/$VIP/port/$PORT/protocol/tcp" >/dev/null
echo; echo "===== 세션별 사용 파드 수 (1=한 파드 고정, >1=흩어짐) ====="
python3 - "$RES" <<'PY'
import sys,collections
rows=[l.split() for l in open(sys.argv[1]) if l.strip()]
for mode in ("rr","epp"):
    bys=collections.defaultdict(set); served=collections.Counter()
    for m,s,t,pod in rows:
        if m!=mode: continue
        if pod!="-": bys[s].add(pod); served[pod]+=1
    per=sorted((int(s),len(p)) for s,p in bys.items())
    one=sum(1 for _,n in per if n==1)
    print(f"[{mode}] 세션별 파드수: {[n for _,n in per]}  →  단일파드 세션 {one}/{len(per)}  (분포 {dict(served)})")
print("판정: RR은 세션이 여러 파드로 흩어지고(>1), EPP는 세션당 1파드로 고정이면 → loxilb RR을 EPP가 덮어씀 = 결정 주체 EPP.")
PY
echo "DONE 증거: $RES"
