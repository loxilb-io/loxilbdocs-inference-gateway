#!/bin/bash
export PATH=$HOME/bin:$PATH KUBECONFIG=$HOME/.kube/config
K="sudo -n /var/lib/rancher/rke2/bin/kubectl --kubeconfig /etc/rancher/rke2/rke2.yaml"
NS=llm-d-pd-disaggregation; LB=http://192.0.2.10:11111; IP=192.0.2.10; MODEL=Qwen/Qwen3-32B-FP8; PORT=8080
R=~/verify-p2; mkdir -p $R
mapfile -t PODS < <($K -n $NS get pods -l llm-d.ai/role=aggregated --field-selector status.phase=Running -o jsonpath='{range .items[*]}{.metadata.name}={.status.podIP}{"\n"}{end}')
PINNAME=${PODS[0]%=*}; PINIP=${PODS[0]#*=}
echo "PIN target: $PINNAME ($PINIP); other pods: ${PODS[1]#*=} ${PODS[2]#*=}"
restore(){ echo ">> RESTORE"; $K -n $NS patch inferencepool pd-disaggregation --type=merge -p '{"spec":{"selector":{"matchLabels":{"llm-d.ai/guide":"pd-disaggregation"}}}}' >/dev/null; $K -n $NS label pod $PINNAME vrfy-pin- --overwrite >/dev/null 2>&1; }
trap restore EXIT
# force EPP to see only pod A
$K -n $NS label pod $PINNAME vrfy-pin=A --overwrite >/dev/null
$K -n $NS patch inferencepool pd-disaggregation --type=merge -p '{"spec":{"selector":{"matchLabels":{"vrfy-pin":"A"}}}}' >/dev/null
echo "patched pool selector -> {vrfy-pin:A}; waiting for EPP to converge"
sleep 12
dist(){ # send $1 requests on current rule; print loxilb dest dist + EPP handled dist
  local n=$1 tag=$2; local START=$(date -u +%Y-%m-%dT%H:%M:%SZ)
  for i in $(seq 1 $n); do curl -s -o /dev/null -m 30 -X POST http://$IP:$PORT/v1/completions -H 'Content-Type: application/json' -H "x-request-id: p2$tag-$i" -d "{\"model\":\"$MODEL\",\"prompt\":\"P2 $tag $i uniq$RANDOM: a color.\",\"max_tokens\":4}"; done
  sleep 2
  echo "  loxilb dest: $($K -n kube-system logs ds/loxilb-lb --since-time=$START 2>/dev/null | grep -oE '\[EPP\] fd=[0-9]+ sid=[0-9]+ -> [0-9.]+' | grep -oE '[0-9.]+$' | sort | uniq -c | tr '\n' ' ')"
  echo "  EPP handled: $($K -n $NS logs deploy/pd-disaggregation-epp -c epp --since-time=$START 2>/dev/null | grep '"Request handled"' | python3 -c 'import sys,json,collections;c=collections.Counter();[c.update([json.loads(l).get("endpoint","?").split(":")[0]]) for l in sys.stdin];print(dict(c))')"
}
# ensure loxilb rule exists (sel=0 RR, FailClose) with all 3 endpoints
EPP_IP=$($K -n $NS get svc pd-disaggregation-epp -o jsonpath='{.spec.clusterIP}')
EPS=""; for kv in "${PODS[@]}"; do EPS="$EPS${EPS:+,}{\"endpointIP\":\"${kv#*=}\",\"targetPort\":8000,\"weight\":1}"; done
mkrule(){ curl -s -X DELETE "$LB/netlox/v1/config/loadbalancer/externalipaddress/$IP/port/$PORT/protocol/tcp" >/dev/null; curl -s -X POST $LB/netlox/v1/config/loadbalancer -H 'Content-Type: application/json' -d "{\"serviceArguments\":{\"externalIP\":\"$IP\",\"port\":$PORT,\"protocol\":\"tcp\",\"mode\":4,\"sel\":$1,\"name\":\"vrfy-epp\",\"eppEndpoint\":\"$EPP_IP:9002\",\"eppFailureMode\":\"FailClose\",\"eppTimeoutMs\":3000},\"endpoints\":[$EPS]}" >/dev/null; sleep 2; }
echo "=== A) EPP forced to pod A, loxilb sel=0 (RR), 60 req  (PASS if ~100% -> $PINIP)"; mkrule 0; dist 60 A
echo "=== B) same but loxilb sel=8 (CHWBL), 40 req  (dist must NOT change -> EPP decides, not loxilb)"; mkrule 8; dist 40 B
echo "PHASE2 DONE $(date -u +%T)"
