#!/bin/bash
# bench_wrap.sh <PORT> <TAG> [extra kvbench args]  -- .35 wrapper: per-pod vLLM counters + loxilb KV metrics before/after
export PATH=$HOME/bin:$PATH KUBECONFIG=$HOME/.kube/config
NS=llm-d-pd-disaggregation; IP=192.0.2.10; PORT=$1; TAG=$2; shift 2
pods() { for pod in $(kubectl get pods -n $NS -l llm-d.ai/role=aggregated -o jsonpath="{.items[*].metadata.name}"); do
  kubectl get --raw "/api/v1/namespaces/$NS/pods/${pod}:8000/proxy/metrics" 2>/dev/null | grep -E "^vllm:(prefix_cache_(hits|queries)_total|request_success_total)" | sed "s/{[^}]*}//" | awk -v p="${pod##*-}" '{a[p" "$1]+=$2} END{for(k in a) printf "%s %d\n", k, a[k]}'; done | sort; }
lb() { curl -s -m 5 http://$IP:11111/netlox/v1/metrics | grep -E "^loxilb_pd_kv_(tier15_(hits|fallthrough)_total|blocks)|^loxilb_pd_kv_tier15_miss_reason_total\{[^}]*\} [1-9]|^loxilb_kv_subscriber_connected"; }
pods > /tmp/bw_p0_$TAG.txt; lb > /tmp/bw_l0_$TAG.txt
python3 ~/kvbench.py --host $IP --port $PORT --tag $TAG --out ~/bench_$TAG.jsonl "$@"
sleep 3; pods > /tmp/bw_p1_$TAG.txt; lb > /tmp/bw_l1_$TAG.txt
echo "--- per-pod vLLM delta (hits/queries = prefix-cache token hit rate during the run)"
awk 'NR==FNR{b[$1" "$2]=$3; next} {k=$1" "$2; d=$3-b[k]; printf "  %s %-32s +%d\n", $1, $2, d; if($2~/hits/)h[$1]=d; if($2~/queries/)q[$1]=d} END{for(k in q) if(q[k]>0) printf "  %s prefix-cache token hit rate this run: %.1f%%\n", k, 100*h[k]/q[k]}' /tmp/bw_p0_$TAG.txt /tmp/bw_p1_$TAG.txt
echo "--- loxilb KV metrics before:"; sed 's/^/  /' /tmp/bw_l0_$TAG.txt; echo "--- after:"; sed 's/^/  /' /tmp/bw_l1_$TAG.txt
