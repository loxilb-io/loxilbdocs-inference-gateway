#!/bin/bash
export PATH=$HOME/bin:$PATH KUBECONFIG=$HOME/.kube/config
K="sudo -n /var/lib/rancher/rke2/bin/kubectl --kubeconfig /etc/rancher/rke2/rke2.yaml"
NS=llm-d-pd-disaggregation; LB=http://192.0.2.10:11111; IP=192.0.2.10; PORT=8080; MODE=$1
EPP_IP=$($K -n $NS get svc pd-disaggregation-epp -o jsonpath='{.spec.clusterIP}')
mapfile -t PODIP < <($K -n $NS get pods -l llm-d.ai/role=aggregated --field-selector status.phase=Running -o jsonpath='{range .items[*]}{.status.podIP}{"\n"}{end}')
EPS=""; for ip in "${PODIP[@]}"; do EPS="$EPS${EPS:+,}{\"endpointIP\":\"$ip\",\"targetPort\":8000,\"weight\":1}"; done
curl -s -X DELETE "$LB/netlox/v1/config/loadbalancer/externalipaddress/$IP/port/$PORT/protocol/tcp">/dev/null
case $MODE in
  epp)   SA="{\"serviceArguments\":{\"externalIP\":\"$IP\",\"port\":$PORT,\"protocol\":\"tcp\",\"mode\":4,\"sel\":0,\"name\":\"c-epp\",\"eppEndpoint\":\"$EPP_IP:9002\",\"eppFailureMode\":\"FailClose\",\"eppTimeoutMs\":3000},\"endpoints\":[$EPS]}";;
  chwbl) SA="{\"serviceArguments\":{\"externalIP\":\"$IP\",\"port\":$PORT,\"protocol\":\"tcp\",\"mode\":4,\"sel\":8,\"name\":\"c-chwbl\"},\"endpoints\":[$EPS]}";;
  rr)    SA="{\"serviceArguments\":{\"externalIP\":\"$IP\",\"port\":$PORT,\"protocol\":\"tcp\",\"mode\":4,\"sel\":0,\"name\":\"c-rr\"},\"endpoints\":[$EPS]}";;
esac
curl -s -X POST $LB/netlox/v1/config/loadbalancer -H 'Content-Type: application/json' -d "$SA" >/dev/null; sleep 2
declare -A H0 Q0; for ip in "${PODIP[@]}"; do m=$(curl -s -m5 http://$ip:8000/metrics); H0[$ip]=$(echo "$m"|awk '/^vllm:prefix_cache_hits_total/{s+=$NF}END{print s+0}'); Q0[$ip]=$(echo "$m"|awk '/^vllm:prefix_cache_queries_total/{s+=$NF}END{print s+0}'); done
SALT=$MODE$RANDOM
python3 ~/qa_cache.py $IP $PORT 8 15 $MODE $SALT > ~/cache_$MODE.sent 2>/dev/null
th=0;tq=0; for ip in "${PODIP[@]}"; do m=$(curl -s -m5 http://$ip:8000/metrics); h=$(echo "$m"|awk '/^vllm:prefix_cache_hits_total/{s+=$NF}END{print s+0}'); q=$(echo "$m"|awk '/^vllm:prefix_cache_queries_total/{s+=$NF}END{print s+0}'); th=$((th+h-${H0[$ip]})); tq=$((tq+q-${Q0[$ip]})); done
hr=$(python3 -c "print('%.1f'%(100.0*$th/$tq) if $tq else 0)")
echo "MODE=$MODE  sent=$(wc -l < ~/cache_$MODE.sent) ok=$(grep -c ' 200' ~/cache_$MODE.sent)  prefix_cache_hit=${hr}%  (hits=$th queries=$tq)"
