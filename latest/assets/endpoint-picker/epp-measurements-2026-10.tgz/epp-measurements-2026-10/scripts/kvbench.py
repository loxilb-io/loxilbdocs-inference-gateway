#!/usr/bin/env python3
"""Multi-session prefix-reuse benchmark for RR vs KV-exact routing.

S sessions, each with a unique ~W-word prefix (a long system prompt) and T turns.
Turn k's prompt = prefix + history(Q1 A1 .. Qk-1 Ak-1) + Qk, so every turn is a
strict extension of the previous turn's prompt + generated answer. Rounds are
turn-major: all sessions run turn 1 (C concurrent), then all run turn 2, ... so
between two turns of one session many other sessions hit the pods.

Per request: TTFT (first SSE chunk with text), E2E, prompt/completion tokens.
Summary: cold (turn 1) vs warm (turn>=2) TTFT/E2E p50/p95/mean.
"""
import argparse, json, random, sys, time, threading, http.client
from concurrent.futures import ThreadPoolExecutor

VOCAB = ("gateway router cache prefix block hash tensor kernel latency throughput cluster "
         "endpoint session context window attention decode prefill schedule batch token "
         "memory bandwidth replica picker weight scorer affinity queue stream chunk header "
         "socket proxy balance metric counter event subscribe publish worker inventory ledger "
         "policy threshold warmup fallback mirror shard rank device driver module vector "
         "matrix layer embedding logits sampler beam greedy prompt answer question system "
         "assistant user turn dialogue history summary document paragraph sentence word").split()

def make_prefix(tag, s, words):
    r = random.Random(f"{tag}-{s}")
    body = " ".join(r.choice(VOCAB) for _ in range(words))
    return f"Session {tag}-{s} system context. " + body + "\n"

def one_request(host, port, model, prompt, max_tokens, timeout):
    body = json.dumps({"model": model, "prompt": prompt, "max_tokens": max_tokens,
                       "temperature": 0, "stream": True,
                       "stream_options": {"include_usage": True}})
    t0 = time.perf_counter(); ttft = None; text = []; usage = None; status = None
    conn = http.client.HTTPConnection(host, port, timeout=timeout)
    try:
        conn.request("POST", "/v1/completions", body=body,
                     headers={"Content-Type": "application/json"})
        resp = conn.getresponse(); status = resp.status
        if status != 200:
            return {"status": status, "err": resp.read(300).decode(errors="replace"),
                    "ttft": None, "e2e": time.perf_counter() - t0, "text": "", "usage": None}
        buf = b""
        while True:
            chunk = resp.read1(65536) if hasattr(resp, "read1") else resp.read(65536)
            if not chunk:
                break
            buf += chunk
            while b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                line = line.strip()
                if not line.startswith(b"data:"):
                    continue
                data = line[5:].strip()
                if data == b"[DONE]":
                    buf = b""; chunk = b""; break
                try:
                    j = json.loads(data)
                except Exception:
                    continue
                if j.get("usage"):
                    usage = j["usage"]
                for ch in j.get("choices", []):
                    tx = ch.get("text", "")
                    if tx:
                        if ttft is None:
                            ttft = time.perf_counter() - t0
                        text.append(tx)
            if not chunk:
                break
    finally:
        conn.close()
    return {"status": status, "ttft": ttft, "e2e": time.perf_counter() - t0,
            "text": "".join(text), "usage": usage}

def pct(v, p):
    if not v: return None
    v = sorted(v); k = (len(v) - 1) * p / 100.0
    f = int(k); c = min(f + 1, len(v) - 1)
    return v[f] + (v[c] - v[f]) * (k - f)

def stats(v):
    v = [x for x in v if x is not None]
    if not v: return {"n": 0}
    return {"n": len(v), "mean": sum(v) / len(v), "p50": pct(v, 50), "p95": pct(v, 95),
            "min": min(v), "max": max(v)}

def fmt(st):
    if st.get("n", 0) == 0: return "n=0"
    return (f"n={st['n']:<3d} mean={st['mean']*1000:7.1f}ms p50={st['p50']*1000:7.1f}ms "
            f"p95={st['p95']*1000:7.1f}ms max={st['max']*1000:7.1f}ms")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", required=True); ap.add_argument("--port", type=int, required=True)
    ap.add_argument("--model", default="Qwen/Qwen3-32B-FP8")
    ap.add_argument("--sessions", type=int, default=12); ap.add_argument("--turns", type=int, default=6)
    ap.add_argument("--concurrency", type=int, default=4); ap.add_argument("--words", type=int, default=4500)
    ap.add_argument("--max-tokens", type=int, default=32); ap.add_argument("--tag", required=True)
    ap.add_argument("--timeout", type=float, default=180); ap.add_argument("--out", default=None)
    a = ap.parse_args()

    sessions = [{"id": s, "prefix": make_prefix(a.tag, s, a.words), "hist": ""} for s in range(a.sessions)]
    rows = []; lock = threading.Lock(); wall0 = time.perf_counter()

    def run_turn(sess, k):
        q = f"Question {k}: in one short sentence, what does the word number {k*7 % 50 + 1} of the context say?"
        prompt = sess["prefix"] + sess["hist"] + q + "\nAnswer:"
        r = one_request(a.host, a.port, a.model, prompt, a.max_tokens, a.timeout)
        sess["hist"] += q + "\nAnswer:" + r["text"] + "\n"
        row = {"session": sess["id"], "turn": k, "status": r["status"], "ttft": r["ttft"], "e2e": r["e2e"],
               "prompt_tokens": (r["usage"] or {}).get("prompt_tokens"),
               "completion_tokens": (r["usage"] or {}).get("completion_tokens"), "err": r.get("err")}
        with lock:
            rows.append(row)
        return row

    order_rng = random.Random(a.tag + "-order")
    for k in range(1, a.turns + 1):
        t0 = time.perf_counter()
        # shuffle the arrival order every turn: with a fixed order and S % pods == 0 a strict
        # round-robin balancer would send each session to the same pod every turn (fake affinity)
        turn_sessions = sessions[:]; order_rng.shuffle(turn_sessions)
        with ThreadPoolExecutor(max_workers=a.concurrency) as ex:
            res = list(ex.map(lambda s: run_turn(s, k), turn_sessions))
        ok = sum(1 for r in res if r["status"] == 200)
        tt = stats([r["ttft"] for r in res]); pt = [r["prompt_tokens"] for r in res if r["prompt_tokens"]]
        print(f"turn {k}: ok={ok}/{len(res)} wall={time.perf_counter()-t0:6.2f}s "
              f"prompt_tokens~{(sum(pt)//len(pt)) if pt else '?'} ttft {fmt(tt)}", flush=True)

    wall = time.perf_counter() - wall0
    cold = [r for r in rows if r["turn"] == 1]; warm = [r for r in rows if r["turn"] >= 2]
    errs = [r for r in rows if r["status"] != 200]
    print(f"\n=== {a.tag} :{a.port} sessions={a.sessions} turns={a.turns} conc={a.concurrency} "
          f"words={a.words} requests={len(rows)} errors={len(errs)} wall={wall:.1f}s")
    print(f"cold TTFT (turn 1)  : {fmt(stats([r['ttft'] for r in cold]))}")
    print(f"warm TTFT (turn>=2) : {fmt(stats([r['ttft'] for r in warm]))}")
    print(f"cold E2E  (turn 1)  : {fmt(stats([r['e2e'] for r in cold]))}")
    print(f"warm E2E  (turn>=2) : {fmt(stats([r['e2e'] for r in warm]))}")
    # per-session warm TTFT: shows sessions that never got a cache hit
    per = {}
    for r in warm:
        per.setdefault(r["session"], []).append(r["ttft"])
    line = " ".join(f"s{s}:{(stats(v)['p50'] or 0)*1000:.0f}" for s, v in sorted(per.items()))
    print(f"per-session warm TTFT p50 (ms): {line}")
    if errs:
        print("errors:", [(r["session"], r["turn"], r["status"], (r["err"] or "")[:80]) for r in errs][:5])
    if a.out:
        with open(a.out, "w") as f:
            for r in rows: f.write(json.dumps(r) + "\n")

if __name__ == "__main__":
    main()
