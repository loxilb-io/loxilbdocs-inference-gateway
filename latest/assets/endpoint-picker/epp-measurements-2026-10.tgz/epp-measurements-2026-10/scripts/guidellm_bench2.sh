#!/bin/bash
# B2) guidellm 다중 프리픽스 — A(kvbench)와 같은 조건. prefix_count=40 고유 프리픽스,
# 각 프리픽스가 여러 요청에 재사용 → 모드별 캐시 재사용 비교가 의미있게 됨.
set -u
export PATH=$HOME/.local/bin:$PATH
K="sudo -n /var/lib/rancher/rke2/bin/kubectl --kubeconfig /etc/rancher/rke2/rke2.yaml"
NS=llm-d-pd-disaggregation
VIP=192.0.2.11; API=http://$VIP:11111/netlox/v1; PORT=${PORT:-8088}
MODEL=Qwen/Qwen3-32B-FP8; STREAMS=${STREAMS:-16}; PFXN=${PFXN:-40}; TOK=${TOK:-gpt2}
OUT=${OUT:-$HOME/guidellm_bench2_$(date +%Y%m%dT%H%M%S)}; mkdir -p "$OUT"
echo "결과 디렉토리: $OUT (STREAMS=$STREAMS prefix_count=$PFXN)"

mapfile -t IPS < <($K -n $NS get pods -l llm-d.ai/role=aggregated -o json 2>/dev/null | python3 -c '
import sys,json
for p in json.load(sys.stdin)["items"]:
    cs=p["status"].get("containerStatuses",[])
    if p["status"]["phase"]=="Running" and cs and all(c.get("ready") for c in cs):
        print(p["status"]["podIP"])')
echo "READY 파드: ${IPS[*]:-none} (${#IPS[@]}개)"
[ ${#IPS[@]} -lt 2 ] && { echo "Ready 파드 부족 → 중단"; exit 1; }
EPP_IP=$($K -n $NS get svc pd-disaggregation-epp -o jsonpath='{.spec.clusterIP}'); echo "EPP ClusterIP=$EPP_IP"
EPS=""; for ip in "${IPS[@]}"; do EPS="$EPS${EPS:+,}{\"endpointIP\":\"$ip\",\"targetPort\":8000,\"weight\":1}"; done

metric_sum(){ curl -s -m5 http://$1:8000/metrics 2>/dev/null | awk -v k="$2" '$0 ~ "^"k"[ {]"{s+=$NF}END{print s+0}'; }
snap(){ local tag=$1; local f=$OUT/snap_$tag.txt; : > $f; for ip in "${IPS[@]}"; do
    echo "$ip $(metric_sum $ip vllm:prefix_cache_queries_total) $(metric_sum $ip vllm:prefix_cache_hits_total)" >> $f; done; }
mkrule(){ local mode=$1 sel epp name
  case $mode in
    epp)   sel=0; name=cache-epp;   epp=",\"eppEndpoint\":\"$EPP_IP:9002\",\"eppFailureMode\":\"FailClose\",\"eppTimeoutMs\":5000";;
    chwbl) sel=8; name=cache-chwbl; epp="";;
    rr)    sel=0; name=cache-rr;    epp="";;
  esac
  curl -s -X DELETE "$API/config/loadbalancer/externalipaddress/$VIP/port/$PORT/protocol/tcp" >/dev/null
  curl -s -X POST $API/config/loadbalancer -H 'Content-Type: application/json' \
    -d "{\"serviceArguments\":{\"externalIP\":\"$VIP\",\"port\":$PORT,\"protocol\":\"tcp\",\"mode\":4,\"sel\":$sel,\"name\":\"$name\"$epp},\"endpoints\":[$EPS]}" >/dev/null
  sleep 2; }

SUMMARY=$OUT/summary.tsv
echo -e "scenario\tmode\tcache_reuse\treq_s\tttft_p50\tttft_p95\tlat_p50\tpod_dist\tok\terr" > $SUMMARY

run_scn(){ local scn=$1 ptok=$2 otok=$3 xtok=$4 cnt=$5
  echo "========== $scn (prompt=$ptok out=$otok prefix=$xtok x$PFXN count=$cnt) =========="
  for mode in epp chwbl rr; do
    echo "----- $scn / $mode  $(date +%H:%M:%S) -----"
    mkrule $mode
    snap "${scn}_${mode}_before"
    guidellm run \
      --backend kind=openai_http,target=http://$VIP:$PORT,model=$MODEL \
      --data kind=synthetic_text,prompt_tokens=$ptok,output_tokens=$otok,prefix_tokens=$xtok,prefix_count=$PFXN \
      --profile kind=concurrent --override profile.streams $STREAMS \
      --constraint kind=max_requests,count=$cnt \
      --tokenizer kind=hf_auto,model=$TOK \
      --output kind=json,path=$OUT/g_${mode}_${scn}.json \
      --disable-progress > $OUT/g_${mode}_${scn}.out 2>&1
    snap "${scn}_${mode}_after"
    # 파드별 queries 증가 분포 (EPP가 40개 프리픽스를 파드에 어떻게 퍼뜨리나)
    PD=$(paste $OUT/snap_${scn}_${mode}_before.txt $OUT/snap_${scn}_${mode}_after.txt | awk '{printf "%d ", $5-$2}')
    python3 - "$OUT/snap_${scn}_${mode}_before.txt" "$OUT/snap_${scn}_${mode}_after.txt" "$OUT/g_${mode}_${scn}.json" "$scn" "$mode" "$PD" >> $SUMMARY <<'PY'
import sys,json
bf,af,js,scn,mode,pd=sys.argv[1:7]
def load(f):
    q=h=0
    for l in open(f):
        _,qq,hh=l.split(); q+=int(float(qq)); h+=int(float(hh))
    return q,h
q0,h0=load(bf); q1,h1=load(af); dq=q1-q0; dh=h1-h0
reuse="%.1f%%"%(100*dh/dq) if dq else "n/a"
def g(d,*ks):
    for k in ks:
        if isinstance(d,dict) and k in d: d=d[k]
        else: return None
    return d
try:
    d=json.load(open(js)); m=d["benchmarks"][0]["metrics"]
    reqs=g(m,"requests_per_second","successful","mean")
    ttp50=g(m,"time_to_first_token_ms","successful","percentiles","p50")
    ttp95=g(m,"time_to_first_token_ms","successful","percentiles","p95")
    latp50=g(m,"request_latency","successful","percentiles","p50")
    ok=g(m,"request_totals","successful"); err=g(m,"request_totals","errored")
    f=lambda x,s=1: ("%.1f"%(x*s)) if isinstance(x,(int,float)) else "?"
    pds="/".join(pd.split())
    row=[scn,mode,reuse,f(reqs),f(ttp50),f(ttp95),f(latp50,1000),pds,str(ok),str(err)]
except Exception as e:
    row=[scn,mode,reuse,"ERR","","","","",str(e)[:30],""]
print("\t".join(row))
PY
    echo "   $(tail -1 $SUMMARY)"
  done; }

# A와 같은 요청 수: long 600(=40x15), short 240(=40x6)
run_scn long 2100 32 2000 600
run_scn short 200 16 120 240

curl -s -X DELETE "$API/config/loadbalancer/externalipaddress/$VIP/port/$PORT/protocol/tcp" >/dev/null
echo; echo "========== 요약 (B2/guidellm 다중프리픽스, lat_p50=ms, pod_dist=파드별 queries) =========="; column -t -s$'\t' $SUMMARY
echo "GUIDELLM_BENCH2 DONE -> $OUT"
