#!/bin/bash
export PATH=$HOME/bin:$PATH KUBECONFIG=$HOME/.kube/config
K="sudo -n /var/lib/rancher/rke2/bin/kubectl --kubeconfig /etc/rancher/rke2/rke2.yaml"
NS=llm-d-pd-disaggregation; LB=http://192.0.2.10:11111; IP=192.0.2.10; MODEL=Qwen/Qwen3-32B-FP8
N=${N:-10}; PORT=${PORT:-8080}
EPP_IP=$($K -n $NS get svc pd-disaggregation-epp -o jsonpath='{.spec.clusterIP}')
mapfile -t PODIP < <($K -n $NS get pods -l llm-d.ai/role=aggregated --field-selector status.phase=Running -o jsonpath='{range .items[*]}{.status.podIP}{"\n"}{end}')
EPS=""; for ip in "${PODIP[@]}"; do EPS="$EPS${EPS:+,}{\"endpointIP\":\"$ip\",\"targetPort\":8000,\"weight\":1}"; done
curl -s -X DELETE "$LB/config/loadbalancer/externalipaddress/$IP/port/$PORT/protocol/tcp" >/dev/null 2>&1
curl -s -X DELETE "$LB/netlox/v1/config/loadbalancer/externalipaddress/$IP/port/$PORT/protocol/tcp" >/dev/null
curl -s -X POST $LB/netlox/v1/config/loadbalancer -H 'Content-Type: application/json' -d "{\"serviceArguments\":{\"externalIP\":\"$IP\",\"port\":$PORT,\"protocol\":\"tcp\",\"mode\":4,\"sel\":0,\"name\":\"vrfy-epp\",\"eppEndpoint\":\"$EPP_IP:9002\",\"eppFailureMode\":\"FailClose\",\"eppTimeoutMs\":3000},\"endpoints\":[$EPS]}" >/dev/null
sleep 2
echo "RULE: :$PORT FailClose EPP=$EPP_IP:9002 pods=${PODIP[*]}"
req_before=$(curl -s $LB/netlox/v1/metrics | awk '/^loxilb_ai_epp_requests_total/{s+=$NF} END{print s+0}')
declare -A PA; for ip in "${PODIP[@]}"; do PA[$ip]=$(curl -s -m5 http://$ip:8000/metrics | awk '/^vllm:request_success_total/{s+=$NF} END{print s+0}'); done
START=$(date -u +%Y-%m-%dT%H:%M:%SZ); echo "START=$START"
for i in $(seq 1 $N); do rid=$(printf "vrfy-%03d" $i)
  code=$(curl -s -o /dev/null -w '%{http_code}' -m 30 -X POST http://$IP:$PORT/v1/completions -H 'Content-Type: application/json' -H "x-request-id: $rid" -d "{\"model\":\"$MODEL\",\"prompt\":\"MARK $rid: name one color.\",\"max_tokens\":4}")
  echo "sent $rid -> http $code"
done
sleep 2
req_after=$(curl -s $LB/netlox/v1/metrics | awk '/^loxilb_ai_epp_requests_total/{s+=$NF} END{print s+0}')
echo "=== loxilb_ai_epp_requests_total: $req_before -> $req_after (delta $((req_after-req_before)), sent $N)"
echo "=== per-pod vllm:request_success_total delta"; for ip in "${PODIP[@]}"; do a=$(curl -s -m5 http://$ip:8000/metrics | awk '/^vllm:request_success_total/{s+=$NF} END{print s+0}'); echo "  $ip: ${PA[$ip]} -> $a (+$((a-${PA[$ip]})))"; done
echo "=== loxilb [EPP] decision lines (since START)"; $K -n kube-system logs ds/loxilb-lb --since-time="$START" 2>/dev/null | grep -E "\[EPP\]" | grep -E "decision:|-> " | tail -40 | cut -c1-200
echo "=== EPP v=4 scheduling logs (since START)"; $K -n $NS logs deploy/pd-disaggregation-epp -c epp --since-time="$START" 2>/dev/null | grep -iE "picked|result|score|endpoint|chose|target|select" | tail -40 | cut -c1-240
echo "PHASE1 DONE $(date -u +%T)"
