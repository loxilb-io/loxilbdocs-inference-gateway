#!/bin/bash
# Q3 cold->warm: 한 대화를 턴별로 보내며 EPP 미지→학습 동작을 로그+수치로 캡처
set -u
K="sudo -n /var/lib/rancher/rke2/bin/kubectl --kubeconfig /etc/rancher/rke2/rke2.yaml"
NS=llm-d-pd-disaggregation; LB=http://192.0.2.10:11111; IP=192.0.2.10; PORT=8080; MODEL=Qwen/Qwen3-32B-FP8
mapfile -t KV < <($K -n $NS get pods -l llm-d.ai/role=aggregated --field-selector status.phase=Running -o jsonpath='{range .items[*]}{.metadata.name}={.status.podIP}{"\n"}{end}')
NM=(); P=(); for kv in "${KV[@]}"; do NM+=(${kv%=*}); P+=(${kv#*=}); done
P1=${P[0]} P2=${P[1]} P3=${P[2]}
echo "pods: P1=$P1  P2=$P2  P3=$P3"
EPP_IP=$($K -n $NS get svc pd-disaggregation-epp -o jsonpath='{.spec.clusterIP}')

# ---- EPP를 v=4로 (container[1]=epp) ----
echo "== raise EPP to --v=4 =="
CUR=$($K -n $NS get deploy pd-disaggregation-epp -o jsonpath='{.spec.template.spec.containers[1].args}')
NEWARGS=$(python3 -c "import json,sys; a=json.loads(sys.argv[1]); a=[('--v=4' if x.startswith('--v=') else x) for x in a]; print(json.dumps(a))" "$CUR")
$K -n $NS patch deploy pd-disaggregation-epp --type=json -p "[{\"op\":\"replace\",\"path\":\"/spec/template/spec/containers/1/args\",\"value\":$NEWARGS}]" >/dev/null
$K -n $NS rollout status deploy/pd-disaggregation-epp --timeout=180s
sleep 5

# ---- loxilb EPP 룰 (3파드) ----
EPS="{\"endpointIP\":\"$P1\",\"targetPort\":8000,\"weight\":1},{\"endpointIP\":\"$P2\",\"targetPort\":8000,\"weight\":1},{\"endpointIP\":\"$P3\",\"targetPort\":8000,\"weight\":1}"
curl -s -X DELETE "$LB/netlox/v1/config/loadbalancer/externalipaddress/$IP/port/$PORT/protocol/tcp" >/dev/null
curl -s -X POST $LB/netlox/v1/config/loadbalancer -H 'Content-Type: application/json' -d "{\"serviceArguments\":{\"externalIP\":\"$IP\",\"port\":$PORT,\"protocol\":\"tcp\",\"mode\":4,\"sel\":0,\"name\":\"vrfy-epp\",\"eppEndpoint\":\"$EPP_IP:9002\",\"eppFailureMode\":\"FailClose\",\"eppTimeoutMs\":5000},\"endpoints\":[$EPS]}" >/dev/null
sleep 2

q(){ curl -s -m5 http://$1:8000/metrics 2>/dev/null | awk -v k=$2 '$0 ~ "^"k{s+=$NF}END{print s+0}'; }
snap(){ for ip in $P1 $P2 $P3; do echo "$ip $(q $ip vllm:request_success_total) $(q $ip vllm:prefix_cache_queries_total) $(q $ip vllm:prefix_cache_hits_total)"; done; }
whoserved(){ # args: before-file; prints "IP dq dh" for the pod whose success +1
  local bf=$1; while read ip s0 qq0 h0; do
    s1=$(q $ip vllm:request_success_total)
    if [ "$s1" -gt "$s0" ]; then qq1=$(q $ip vllm:prefix_cache_queries_total); h1=$(q $ip vllm:prefix_cache_hits_total); echo "$ip $((qq1-qq0)) $((h1-h0))"; return; fi
  done < "$bf"; echo "? 0 0"; }

NONCE="$RANDOM$RANDOM"
DOC="SESSION-$NONCE. "; for i in $(seq 1 220); do DOC+="In region $NONCE the fox number $i examined document $i about topic $((i*7%13)) and noted detail $((i*3)). "; done
CONV="$DOC"
LOG=~/p3b_cw.log; : > $LOG
START=$(date -u +%Y-%m-%dT%H:%M:%SZ)
echo "turn servedIP cache_queries cache_hits hit_rate req_id" | tee -a $LOG
for t in $(seq 1 6); do
  rid="c$NONCE-t$(printf %02d $t)"
  CONV+=$'\n'"Q$t: in one word, name color number $t."
  snap > ~/.snapbefore
  curl -s -o /dev/null -m 60 -X POST http://$IP:$PORT/v1/completions -H 'Content-Type: application/json' -H "x-request-id: $rid" \
    --data-binary "$(python3 -c "import json,sys;print(json.dumps({'model':'$MODEL','prompt':sys.stdin.read(),'max_tokens':16,'temperature':0}))" <<<"$CONV")"
  read sip dq dh < <(whoserved ~/.snapbefore)
  hr=$(python3 -c "print('%.1f%%'%(100*$dh/$dq) if $dq else 'n/a')")
  echo "t$t $sip $dq $dh $hr $rid" | tee -a $LOG
  sleep 1
done
echo "=== EPP v=4 스케줄링 로그 (이 대화 요청들) ===" | tee -a $LOG
$K -n $NS logs deploy/pd-disaggregation-epp -c epp --since-time=$START 2>/dev/null | grep -E "c$NONCE-t" | tail -60 >> $LOG
echo "=== loxilb [EPP] -> ip (이 대화) ===" | tee -a $LOG
$K -n kube-system logs ds/loxilb-lb --since-time=$START 2>/dev/null | grep -E '\[EPP\].*-> ' | tail -12 >> $LOG

# ---- 복구: EPP v=2, 룰 삭제 ----
echo "== restore EPP --v=2, delete rule =="
REST=$(python3 -c "import json,sys; a=json.loads(sys.argv[1]); a=[('--v=2' if x.startswith('--v=') else x) for x in a]; print(json.dumps(a))" "$CUR")
$K -n $NS patch deploy pd-disaggregation-epp --type=json -p "[{\"op\":\"replace\",\"path\":\"/spec/template/spec/containers/1/args\",\"value\":$REST}]" >/dev/null
curl -s -X DELETE "$LB/netlox/v1/config/loadbalancer/externalipaddress/$IP/port/$PORT/protocol/tcp" >/dev/null
$K -n $NS rollout status deploy/pd-disaggregation-epp --timeout=180s
echo "P1=$P1 P2=$P2 P3=$P3 NONCE=$NONCE"
echo "PHASE3B DONE"
