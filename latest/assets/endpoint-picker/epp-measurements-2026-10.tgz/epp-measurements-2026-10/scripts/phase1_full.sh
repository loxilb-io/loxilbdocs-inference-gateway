#!/bin/bash
export PATH=$HOME/bin:$PATH KUBECONFIG=$HOME/.kube/config
K="sudo -n /var/lib/rancher/rke2/bin/kubectl --kubeconfig /etc/rancher/rke2/rke2.yaml"
NS=llm-d-pd-disaggregation; LB=http://192.0.2.10:11111; IP=192.0.2.10; MODEL=Qwen/Qwen3-32B-FP8
N=${N:-200}; PORT=8080; R=~/verify-p1; mkdir -p $R
EPP_IP=$($K -n $NS get svc pd-disaggregation-epp -o jsonpath='{.spec.clusterIP}')
mapfile -t PODIP < <($K -n $NS get pods -l llm-d.ai/role=aggregated --field-selector status.phase=Running -o jsonpath='{range .items[*]}{.status.podIP}{"\n"}{end}')
EPS=""; for ip in "${PODIP[@]}"; do EPS="$EPS${EPS:+,}{\"endpointIP\":\"$ip\",\"targetPort\":8000,\"weight\":1}"; done
curl -s -X DELETE "$LB/netlox/v1/config/loadbalancer/externalipaddress/$IP/port/$PORT/protocol/tcp" >/dev/null
curl -s -X POST $LB/netlox/v1/config/loadbalancer -H 'Content-Type: application/json' -d "{\"serviceArguments\":{\"externalIP\":\"$IP\",\"port\":$PORT,\"protocol\":\"tcp\",\"mode\":4,\"sel\":0,\"name\":\"vrfy-epp\",\"eppEndpoint\":\"$EPP_IP:9002\",\"eppFailureMode\":\"FailClose\",\"eppTimeoutMs\":3000},\"endpoints\":[$EPS]}" >/dev/null
sleep 2
rb=$(curl -s $LB/netlox/v1/metrics | awk '/^loxilb_ai_epp_requests_total/{s+=$NF} END{print s+0}')
declare -A PA; for ip in "${PODIP[@]}"; do PA[$ip]=$(curl -s -m5 http://$ip:8000/metrics | awk '/^vllm:request_success_total/{s+=$NF} END{print s+0}'); done
START=$(date -u +%Y-%m-%dT%H:%M:%SZ)
: > $R/sent.txt
for i in $(seq 1 $N); do rid=$(printf "vrfy-%04d" $i)
  code=$(curl -s -o /dev/null -w '%{http_code}' -m 30 -X POST http://$IP:$PORT/v1/completions -H 'Content-Type: application/json' -H "x-request-id: $rid" -d "{\"model\":\"$MODEL\",\"prompt\":\"MARK $rid uniq$RANDOM: name one color.\",\"max_tokens\":4}")
  echo "$rid $code" >> $R/sent.txt
done
sleep 3
ra=$(curl -s $LB/netlox/v1/metrics | awk '/^loxilb_ai_epp_requests_total/{s+=$NF} END{print s+0}')
# collect logs
$K -n kube-system logs ds/loxilb-lb --since-time="$START" 2>/dev/null | grep -E "\[EPP\] fd=.* -> " > $R/loxilb_epp.log
$K -n $NS logs deploy/pd-disaggregation-epp -c epp --since-time="$START" 2>/dev/null | grep '"Request handled"' > $R/epp_handled.log
# per-pod after
: > $R/podafter.txt; for ip in "${PODIP[@]}"; do a=$(curl -s -m5 http://$ip:8000/metrics | awk '/^vllm:request_success_total/{s+=$NF} END{print s+0}'); echo "$ip ${PA[$ip]} $a" >> $R/podafter.txt; done
echo "=== SUMMARY ==="
echo "sent=$N  http200=$(grep -c ' 200' $R/sent.txt)  non200=$(grep -vc ' 200' $R/sent.txt)"
echo "loxilb_ai_epp_requests_total: $rb -> $ra (delta $((ra-rb)))"
echo "loxilb '-> POD' lines: $(wc -l < $R/loxilb_epp.log)"
echo "EPP 'Request handled' lines: $(wc -l < $R/epp_handled.log)"
python3 - "$R" <<'PY'
import sys,json,re,collections
R=sys.argv[1]
# EPP: x-request-id -> endpoint
epp={}
for l in open(R+"/epp_handled.log"):
    try:d=json.loads(l)
    except:continue
    rid=d.get("x-request-id"); ep=d.get("endpoint")
    if rid and ep: epp[rid]=ep.split(":")[0]
# loxilb: ordered list of (sid, ip)
lox=[]
for l in open(R+"/loxilb_epp.log"):
    m=re.search(r'sid=(\d+).*-> (\d+\.\d+\.\d+\.\d+):', l)
    if m: lox.append((int(m.group(1)), m.group(2)))
lox.sort(key=lambda x:x[0])
lox_ips=[ip for _,ip in lox]
# sent order
sent=[l.split()[0] for l in open(R+"/sent.txt") if l.strip()]
epp_ips=[epp.get(r) for r in sent if r in epp]
from collections import Counter
print("EPP decided (handled) for %d of %d req ids"%(len(epp),len(sent)))
print("EPP endpoint distribution:", dict(Counter(epp.values())))
print("loxilb  dest distribution:", dict(Counter(lox_ips)))
pods={}
for l in open(R+"/podafter.txt"):
    ip,b,a=l.split(); pods[ip]=int(a)-int(b)
print("vLLM    served  distribution:", pods)
# per-request join by order (sequential send => order preserved)
n=min(len(epp_ips),len(lox_ips)); match=sum(1 for i in range(n) if epp_ips[i]==lox_ips[i])
print("per-request 3-way (EPP endpoint == loxilb dest) over %d: match=%d (%.1f%%)"%(n,match,100.0*match/n if n else 0))
# distribution equality
d_match = Counter(epp.values())==Counter(lox_ips)==Counter({k:v for k,v in pods.items() if v>0})
print("distribution equality (EPP==loxilb==vLLM):", d_match)
PY
echo "P1FULL DONE $(date -u +%T)"
