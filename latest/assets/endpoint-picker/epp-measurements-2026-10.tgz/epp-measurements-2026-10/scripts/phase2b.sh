#!/bin/bash
# Q2b: loxilb 혼자 고른 파드 vs EPP가 강제한 파드 (요청 위치별 head-to-head)
set -u
K="sudo -n /var/lib/rancher/rke2/bin/kubectl --kubeconfig /etc/rancher/rke2/rke2.yaml"
NS=llm-d-pd-disaggregation; LB=http://192.0.2.10:11111; IP=192.0.2.10; PORT=8080; MODEL=Qwen/Qwen3-32B-FP8
mapfile -t KV < <($K -n $NS get pods -l llm-d.ai/role=aggregated --field-selector status.phase=Running -o jsonpath='{range .items[*]}{.metadata.name}={.status.podIP}{"\n"}{end}')
NM=(); P=(); for kv in "${KV[@]}"; do NM+=(${kv%=*}); P+=(${kv#*=}); done
P1=${P[0]} P2=${P[1]} P3=${P[2]}
echo "pods: P1=$P1  P2=$P2  P3=$P3"
EPP_IP=$($K -n $NS get svc pd-disaggregation-epp -o jsonpath='{.spec.clusterIP}')
EPS="{\"endpointIP\":\"$P1\",\"targetPort\":8000,\"weight\":1},{\"endpointIP\":\"$P2\",\"targetPort\":8000,\"weight\":1},{\"endpointIP\":\"$P3\",\"targetPort\":8000,\"weight\":1}"
succ(){ curl -s -m5 http://$1:8000/metrics 2>/dev/null | awk '/^vllm:request_success_total/{s+=$NF}END{print s+0}'; }
served(){ local a0=$1 b0=$2 c0=$3 t a b c
  for t in $(seq 1 50); do a=$(succ $P1);b=$(succ $P2);c=$(succ $P3)
    [ $a -gt $a0 ] && { echo P1;return; }; [ $b -gt $b0 ] && { echo P2;return; }; [ $c -gt $c0 ] && { echo P3;return; }
    sleep 0.3; done; echo "?"; }
sendone(){ local id=$1 a0 b0 c0; a0=$(succ $P1);b0=$(succ $P2);c0=$(succ $P3)
  curl -s -o /dev/null -m 30 -X POST http://$IP:$PORT/v1/completions -H 'Content-Type: application/json' -H "x-request-id: $id" \
    -d "{\"model\":\"$MODEL\",\"prompt\":\"q2b $id uniq$RANDOM: name a color.\",\"max_tokens\":4}"
  served $a0 $b0 $c0; }
mkrule(){ curl -s -X DELETE "$LB/netlox/v1/config/loadbalancer/externalipaddress/$IP/port/$PORT/protocol/tcp" >/dev/null
  if [ "$2" = 1 ]; then curl -s -X POST $LB/netlox/v1/config/loadbalancer -H 'Content-Type: application/json' \
    -d "{\"serviceArguments\":{\"externalIP\":\"$IP\",\"port\":$PORT,\"protocol\":\"tcp\",\"mode\":4,\"sel\":$1,\"name\":\"vrfy-epp\",\"eppEndpoint\":\"$EPP_IP:9002\",\"eppFailureMode\":\"FailClose\",\"eppTimeoutMs\":3000},\"endpoints\":[$EPS]}" >/dev/null
  else curl -s -X POST $LB/netlox/v1/config/loadbalancer -H 'Content-Type: application/json' \
    -d "{\"serviceArguments\":{\"externalIP\":\"$IP\",\"port\":$PORT,\"protocol\":\"tcp\",\"mode\":4,\"sel\":$1,\"name\":\"vrfy-epp\"},\"endpoints\":[$EPS]}" >/dev/null
  fi; sleep 2; }
NREQ=12
echo "=== BASELINE: loxilb 단독 (EPP 없음), sel=0 RR -> loxilb가 스스로 고른 파드 ==="
mkrule 0 0; declare -a BASE
for i in $(seq 1 $NREQ); do s=$(sendone base-$(printf %02d $i)); BASE[$i]=$s; echo "  req $i -> $s"; done
echo "=== EPP 풀을 P1로 고정 ==="
PIN=${NM[0]}; $K -n $NS label pod $PIN vrfy-pin=A --overwrite >/dev/null
$K -n $NS patch inferencepool pd-disaggregation --type=json -p '[{"op":"replace","path":"/spec/selector/matchLabels","value":{"vrfy-pin":"A"}}]' >/dev/null
sleep 12
echo "=== EPP ON, sel=0 RR 동일, EPP는 P1만 반환 ==="
mkrule 0 1; START=$(date -u +%Y-%m-%dT%H:%M:%SZ); declare -a EPPD
for i in $(seq 1 $NREQ); do s=$(sendone epp-$(printf %02d $i)); EPPD[$i]=$s; echo "  req $i -> $s"; done
$K -n $NS patch inferencepool pd-disaggregation --type=json -p '[{"op":"replace","path":"/spec/selector/matchLabels","value":{"llm-d.ai/guide":"pd-disaggregation"}}]' >/dev/null
$K -n $NS label pod $PIN vrfy-pin- --overwrite >/dev/null 2>&1
echo; echo "idx | loxilb단독(RR) | EPP켬 | 판정"
ov=0
for i in $(seq 1 $NREQ); do d="same"; if [ "${BASE[$i]}" != "${EPPD[$i]}" ]; then d="OVERRIDE: loxilb는 ${BASE[$i]} 인데 EPP가 ${EPPD[$i]} 로 보냄"; ov=$((ov+1)); fi
  printf "%3d | %-13s | %-5s | %s\n" $i "${BASE[$i]}" "${EPPD[$i]}" "$d"; done
echo "override: $ov / $NREQ  (baseline에서 P1이 아니던 요청이 EPP켜니 전부 P1로)"
echo "--- loxilb [EPP] -> ip (EPP run) 분포 ---"
$K -n kube-system logs ds/loxilb-lb --since-time=$START 2>/dev/null | grep -oE '\[EPP\] fd=[0-9]+ sid=[0-9]+ -> [0-9.]+' | grep -oE '[0-9.]+$' | sort | uniq -c
echo "--- EPP 'Request handled' endpoint (EPP run) 분포 ---"
$K -n $NS logs deploy/pd-disaggregation-epp -c epp --since-time=$START 2>/dev/null | grep '"Request handled"' | grep -oE '"endpoint":"[0-9.]+' | sed 's/.*"//' | sort | uniq -c
echo "P1=$P1 P2=$P2 P3=$P3"; echo "PHASE2B DONE"
