#!/bin/bash
set -u
K="sudo -n /var/lib/rancher/rke2/bin/kubectl --kubeconfig /etc/rancher/rke2/rke2.yaml"
NS=llm-d-pd-disaggregation; LB=http://192.0.2.10:11111; IP=192.0.2.10; PORT=8080; MODEL=Qwen/Qwen3-32B-FP8
mapfile -t KV < <($K -n $NS get pods -l llm-d.ai/role=aggregated --field-selector status.phase=Running -o jsonpath='{range .items[*]}{.metadata.name}={.status.podIP}{"\n"}{end}')
P=(); for kv in "${KV[@]}"; do P+=(${kv#*=}); done; P1=${P[0]} P2=${P[1]} P3=${P[2]}
EPP_IP=$($K -n $NS get svc pd-disaggregation-epp -o jsonpath='{.spec.clusterIP}')
echo "epp container name: $($K -n $NS get deploy pd-disaggregation-epp -o jsonpath='{.spec.template.spec.containers[*].name}')"
CUR=$($K -n $NS get deploy pd-disaggregation-epp -o jsonpath='{.spec.template.spec.containers[1].args}')
NEWARGS=$(python3 -c "import json,sys;a=json.loads(sys.argv[1]);a=[('--v=4' if x.startswith('--v=') else x) for x in a];print(json.dumps(a))" "$CUR")
$K -n $NS patch deploy pd-disaggregation-epp --type=json -p "[{\"op\":\"replace\",\"path\":\"/spec/template/spec/containers/1/args\",\"value\":$NEWARGS}]" >/dev/null
$K -n $NS rollout status deploy/pd-disaggregation-epp --timeout=180s; sleep 6
EPOD=$($K -n $NS get pods -l llm-d.ai/role -o name 2>/dev/null | head -1) # fallback
EPOD=$($K -n $NS get pods -o name | grep pd-disaggregation-epp | head -1)
echo "epp pod: $EPOD"
EPS="{\"endpointIP\":\"$P1\",\"targetPort\":8000,\"weight\":1},{\"endpointIP\":\"$P2\",\"targetPort\":8000,\"weight\":1},{\"endpointIP\":\"$P3\",\"targetPort\":8000,\"weight\":1}"
curl -s -X DELETE "$LB/netlox/v1/config/loadbalancer/externalipaddress/$IP/port/$PORT/protocol/tcp" >/dev/null
curl -s -X POST $LB/netlox/v1/config/loadbalancer -H 'Content-Type: application/json' -d "{\"serviceArguments\":{\"externalIP\":\"$IP\",\"port\":$PORT,\"protocol\":\"tcp\",\"mode\":4,\"sel\":0,\"name\":\"vrfy-epp\",\"eppEndpoint\":\"$EPP_IP:9002\",\"eppFailureMode\":\"FailClose\",\"eppTimeoutMs\":5000},\"endpoints\":[$EPS]}" >/dev/null
sleep 2
NONCE="$RANDOM$RANDOM"; DOC="SESSION-$NONCE. "; for i in $(seq 1 180); do DOC+="In zone $NONCE fox $i read file $i on topic $((i*7%13)). "; done
CONV="$DOC"
for t in 1 2 3; do
  rid="c$NONCE-t0$t"; CONV+=$'\n'"Q$t: one word, color $t."
  curl -s -o /dev/null -m 60 -X POST http://$IP:$PORT/v1/completions -H 'Content-Type: application/json' -H "x-request-id: $rid" \
    --data-binary "$(python3 -c "import json,sys;print(json.dumps({'model':'$MODEL','prompt':sys.stdin.read(),'max_tokens':16,'temperature':0}))" <<<"$CONV")"
  echo "sent $rid"; sleep 2
done
sleep 3
echo "===== DEBUG: EPP 로그 원본 마지막 8줄 (필터 없이) ====="
$K -n $NS logs $EPOD -c epp --tail=8 2>&1 | cut -c1-240
echo "===== 이 대화 req_id 로 grep (c$NONCE) ====="
$K -n $NS logs $EPOD -c epp --tail=4000 2>/dev/null | grep "c$NONCE" | cut -c1-240 | tail -20
echo "===== 'Request handled' 최근 6줄 ====="
$K -n $NS logs $EPOD -c epp --tail=4000 2>/dev/null | grep 'Request handled' | tail -6 | cut -c1-240
echo "===== 'prefix' 또는 scorer 흔적 ====="
$K -n $NS logs $EPOD -c epp --tail=4000 2>/dev/null | grep -iE 'prefix|scor|pickedResult|endpoint.*score' | tail -10 | cut -c1-240
echo "NONCE=$NONCE P1=$P1 P2=$P2 P3=$P3"
echo "DBG DONE (아직 복구 안함)"
