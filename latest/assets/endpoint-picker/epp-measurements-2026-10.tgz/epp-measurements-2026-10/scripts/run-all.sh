#!/bin/bash
# One-shot driver (run on the cluster master, e.g. operator@<gateway-node>).
# Prereqs: EPP at --v=4 (see phase0/epp_v4), loxilb features=[epp].
set -e
bash phase0.sh
N=200 bash phase1_full.sh
bash phase2.sh
bash p3b_run.sh epp; bash p3b_run.sh noepp
bash phase6b.sh
bash phase5.sh
echo "see verify/REPORT.md for verdicts"
