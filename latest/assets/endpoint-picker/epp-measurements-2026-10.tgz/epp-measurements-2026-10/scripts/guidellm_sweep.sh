#!/bin/bash
# streams 스윕 → throughput 곡선 (멀티턴, 3모드). 동시성 1..64 한 번에.
set -u
export PATH=$HOME/.local/bin:$PATH
K="sudo -n /var/lib/rancher/rke2/bin/kubectl --kubeconfig /etc/rancher/rke2/rke2.yaml"
NS=llm-d-pd-disaggregation
VIP=192.0.2.11; API=http://$VIP:11111/netlox/v1; PORT=${PORT:-8088}
MODEL=Qwen/Qwen3-32B-FP8; TOK=${TOK:-Qwen/Qwen3-32B-FP8}; PFXN=${PFXN:-40}
STREAMS_LIST=${STREAMS_LIST:-1,4,8,16,32,64}; DUR=${DUR:-40}
OUT=${OUT:-$HOME/guidellm_sweep_$(date +%Y%m%dT%H%M%S)}; mkdir -p "$OUT"
echo "결과: $OUT (streams=$STREAMS_LIST dur=${DUR}s/level, 멀티턴)"
mapfile -t IPS < <($K -n $NS get pods -l llm-d.ai/role=aggregated -o json 2>/dev/null | python3 -c '
import sys,json
for p in json.load(sys.stdin)["items"]:
    cs=p["status"].get("containerStatuses",[])
    if p["status"]["phase"]=="Running" and cs and all(c.get("ready") for c in cs): print(p["status"]["podIP"])')
echo "READY 파드: ${IPS[*]:-none}"; [ ${#IPS[@]} -lt 2 ] && { echo 중단; exit 1; }
EPP_IP=$($K -n $NS get svc pd-disaggregation-epp -o jsonpath='{.spec.clusterIP}')
EPS=""; for ip in "${IPS[@]}"; do EPS="$EPS${EPS:+,}{\"endpointIP\":\"$ip\",\"targetPort\":8000,\"weight\":1}"; done
mkrule(){ local mode=$1 sel epp name
  case $mode in epp) sel=0;name=cache-epp;epp=",\"eppEndpoint\":\"$EPP_IP:9002\",\"eppFailureMode\":\"FailClose\",\"eppTimeoutMs\":5000";;
    chwbl) sel=8;name=cache-chwbl;epp="";; rr) sel=0;name=cache-rr;epp="";; esac
  curl -s -X DELETE "$API/config/loadbalancer/externalipaddress/$VIP/port/$PORT/protocol/tcp" >/dev/null
  curl -s -X POST $API/config/loadbalancer -H 'Content-Type: application/json' \
    -d "{\"serviceArguments\":{\"externalIP\":\"$VIP\",\"port\":$PORT,\"protocol\":\"tcp\",\"mode\":4,\"sel\":$sel,\"name\":\"$name\"$epp},\"endpoints\":[$EPS]}" >/dev/null; sleep 2; }
SUMMARY=$OUT/curve.tsv
echo -e "mode\tstreams\treq_s\ttok_s\tttft_p50\tttft_p95\tlat_p50\tok\terr" > $SUMMARY
for mode in epp chwbl rr; do
  echo "===== $mode  $(date +%H:%M:%S) ====="; mkrule $mode
  guidellm run \
    --backend kind=openai_http,target=http://$VIP:$PORT,model=$MODEL,request_format=/v1/chat/completions \
    --data kind=synthetic_text,prompt_tokens=100,output_tokens=32,turns=15,prefix_tokens=2000,prefix_count=$PFXN \
    --profile kind=concurrent --override profile.streams $STREAMS_LIST \
    --constraint kind=max_duration,seconds=$DUR \
    --tokenizer kind=hf_auto,model=$TOK \
    --output kind=json,path=$OUT/sweep_${mode}.json \
    --disable-progress > $OUT/sweep_${mode}.out 2>&1
  python3 - "$OUT/sweep_${mode}.json" "$mode" >> $SUMMARY <<'PY'
import sys,json
js,mode=sys.argv[1:3]
def g(d,*ks):
    for k in ks:
        if isinstance(d,dict) and k in d: d=d[k]
        else: return None
    return d
def f(x,s=1): return ("%.1f"%(x*s)) if isinstance(x,(int,float)) else "?"
d=json.load(open(js))
for b in d.get("benchmarks",[]):
    m=b.get("metrics",{})
    # streams 찾기
    st=g(b,"config","profile","streams") or g(b,"config","strategy","streams") or g(b,"scheduler_state","num_processes")
    if isinstance(st,list): st=st[0] if st else "?"
    reqs=g(m,"requests_per_second","successful","mean")
    toks=g(m,"output_tokens_per_second","successful","mean")
    ttp50=g(m,"time_to_first_token_ms","successful","percentiles","p50")
    ttp95=g(m,"time_to_first_token_ms","successful","percentiles","p95")
    latp50=g(m,"request_latency","successful","percentiles","p50")
    ok=g(m,"request_totals","successful"); err=g(m,"request_totals","errored")
    print("\t".join([mode,str(st),f(reqs),f(toks),f(ttp50),f(ttp95),f(latp50,1000),str(ok),str(err)]))
PY
  echo "   $(grep -c "^$mode" $SUMMARY) levels done"
done
curl -s -X DELETE "$API/config/loadbalancer/externalipaddress/$VIP/port/$PORT/protocol/tcp" >/dev/null
echo; echo "===== THROUGHPUT 곡선 ====="; column -t -s$'\t' $SUMMARY
echo "SWEEP DONE -> $OUT"
