import sys,time,json,http.client,random,urllib.request
host,port,S,T,tagbase=sys.argv[1],int(sys.argv[2]),int(sys.argv[3]),int(sys.argv[4]),sys.argv[5]
PODS=sys.argv[6].split(",")   # pod IPs
MODEL="Qwen/Qwen3-32B-FP8"
def succ(ip):
    try:
        d=urllib.request.urlopen("http://%s:8000/metrics"%ip,timeout=5).read().decode()
        return sum(float(l.split()[-1]) for l in d.splitlines() if l.startswith("vllm:request_success_total"))
    except: return -1
TOPICS=["Roman aqueduct engineering","deep-sea bioluminescence","medieval guild economics","jet engine thermodynamics","Andean terrace agriculture","quantum error correction","Baroque counterpoint","coral reef symbiosis"]
def preamble(i):
    t=TOPICS[i%len(TOPICS)]
    base="You are a patient expert tutor on %s (session %d). Keep a coherent thread, refer back. "%(t,i)
    pad=" ".join("On %s, key fact %d is that the subject rewards concrete explanation with examples."%(t,j) for j in range(60))
    return base+pad+"\n\n"
sessions=[{"id":i,"pre":preamble(i),"hist":[]} for i in range(S)]
QS=["Give a simple overview.","Most common misconception?","Explain the core mechanism step by step.","How does it compare to a related idea?","A concrete real-world example?","Why did it develop this way?","Main trade-offs?","Walk through a worked case.","What would an expert add?","Summarize so far."]
last={ip:succ(ip) for ip in PODS}
def served():
    time.sleep(0.2)
    cur={ip:succ(ip) for ip in PODS}
    got=[ip for ip in PODS if cur[ip]-last[ip]>=1]
    for ip in PODS: last[ip]=cur[ip]
    return got[0] if len(got)==1 else ("AMBIG:"+",".join(got) if got else "NONE")
def send(sess,k):
    q=QS[k%len(QS)]; prompt=sess["pre"]
    for (u,a) in sess["hist"]: prompt+="Q: "+u+"\nA: "+a+"\n"
    prompt+="Q: "+q+"\nA:"
    rid="%s-s%02d-t%02d"%(tagbase,sess["id"],k)
    body=json.dumps({"model":MODEL,"prompt":prompt,"max_tokens":48,"temperature":0,"stream":True})
    t0=time.perf_counter();ttft=None;txt=[];code=0
    try:
        c=http.client.HTTPConnection(host,port,timeout=90)
        c.request("POST","/v1/completions",body=body,headers={"Content-Type":"application/json","x-request-id":rid})
        r=c.getresponse();code=r.status;buf=b""
        if code==200:
            while True:
                ch=r.read1(65536) if hasattr(r,"read1") else r.read(4096)
                if not ch:break
                buf+=ch
                while b"\n" in buf:
                    ln,buf=buf.split(b"\n",1);ln=ln.strip()
                    if not ln.startswith(b"data:"):continue
                    d=ln[5:].strip()
                    if d==b"[DONE]":break
                    try:j=json.loads(d)
                    except:continue
                    for cc in j.get("choices",[]):
                        tx=cc.get("text","")
                        if tx:
                            if ttft is None:ttft=time.perf_counter()-t0
                            txt.append(tx)
        else:r.read()
        c.close()
    except: code=-1
    sess["hist"].append((q,"".join(txt).strip() or "(ok)"))
    pod=served()
    print("%s %d %d %s %.3f %s"%(rid,sess["id"],k,code,(ttft if ttft else time.perf_counter()-t0),pod));sys.stdout.flush()
for k in range(T):
    order=list(range(S));random.shuffle(order)
    for sid in order: send(sessions[sid],k)
