#!/bin/bash
# Q6 단계별: baseline(EPP up) -> EPP 진짜 다운 확인 -> FailClose 503 -> FailOpen 200(loxilb분배) -> 복구
set -u
K="sudo -n /var/lib/rancher/rke2/bin/kubectl --kubeconfig /etc/rancher/rke2/rke2.yaml"
NS=llm-d-pd-disaggregation; LB=http://192.0.2.10:11111; IP=192.0.2.10; PORT=8080; MODEL=Qwen/Qwen3-32B-FP8
mapfile -t KV < <($K -n $NS get pods -l llm-d.ai/role=aggregated --field-selector status.phase=Running -o jsonpath='{range .items[*]}{.status.podIP}{"\n"}{end}')
P1=${KV[0]} P2=${KV[1]} P3=${KV[2]}; echo "pods: $P1 $P2 $P3"
EPP_IP=$($K -n $NS get svc pd-disaggregation-epp -o jsonpath='{.spec.clusterIP}'); echo "EPP clusterIP=$EPP_IP"
REPL=$($K -n $NS get deploy pd-disaggregation-epp -o jsonpath='{.spec.replicas}'); echo "EPP replicas(orig)=$REPL"
EPS="{\"endpointIP\":\"$P1\",\"targetPort\":8000,\"weight\":1},{\"endpointIP\":\"$P2\",\"targetPort\":8000,\"weight\":1},{\"endpointIP\":\"$P3\",\"targetPort\":8000,\"weight\":1}"
mkrule(){ curl -s -X DELETE "$LB/netlox/v1/config/loadbalancer/externalipaddress/$IP/port/$PORT/protocol/tcp" >/dev/null
  curl -s -X POST $LB/netlox/v1/config/loadbalancer -H 'Content-Type: application/json' -d "{\"serviceArguments\":{\"externalIP\":\"$IP\",\"port\":$PORT,\"protocol\":\"tcp\",\"mode\":4,\"sel\":0,\"name\":\"vrfy-epp\",\"eppEndpoint\":\"$EPP_IP:9002\",\"eppFailureMode\":\"$1\",\"eppTimeoutMs\":3000},\"endpoints\":[$EPS]}" >/dev/null; sleep 2; }
q(){ curl -s -m5 http://$1:8000/metrics 2>/dev/null | awk -v k=$2 '$0 ~ "^"k{s+=$NF}END{print s+0}'; }
served(){ local a0=$1 b0=$2 c0=$3 t a b c; for t in $(seq 1 20); do a=$(q $P1 vllm:request_success_total);b=$(q $P2 vllm:request_success_total);c=$(q $P3 vllm:request_success_total); [ $a -gt $a0 ]&&{ echo $P1;return;}; [ $b -gt $b0 ]&&{ echo $P2;return;}; [ $c -gt $c0 ]&&{ echo $P3;return;}; sleep 0.3; done; echo "-"; }
send_codes(){ local n=$1 tag=$2 f=$3; : > $f; for i in $(seq 1 $n); do r=$(curl -s -o /dev/null -m 20 -w '%{http_code} %{time_total}' -X POST http://$IP:$PORT/v1/completions -H 'Content-Type: application/json' -H "x-request-id: $tag-$i" -d "{\"model\":\"$MODEL\",\"prompt\":\"q6 $tag $i uniq$RANDOM: a color.\",\"max_tokens\":4}"); echo "$tag-$i $r" >> $f; done; }
send_attrib(){ local n=$1 tag=$2 f=$3; : > $f; for i in $(seq 1 $n); do a0=$(q $P1 vllm:request_success_total);b0=$(q $P2 vllm:request_success_total);c0=$(q $P3 vllm:request_success_total); r=$(curl -s -o /dev/null -m 20 -w '%{http_code} %{time_total}' -X POST http://$IP:$PORT/v1/completions -H 'Content-Type: application/json' -H "x-request-id: $tag-$i" -d "{\"model\":\"$MODEL\",\"prompt\":\"q6 $tag $i uniq$RANDOM: a color.\",\"max_tokens\":4}"); sip=$(served $a0 $b0 $c0); echo "$tag-$i $r $sip" >> $f; done; }

echo "===== STEP 0 baseline (EPP up, FailClose rule) ====="
mkrule FailClose; T0=$(date -u +%Y-%m-%dT%H:%M:%SZ); send_attrib 5 base ~/q6_base.txt
echo "codes: $(awk '{print $2}' ~/q6_base.txt | sort | uniq -c | tr '\n' ' ')"; echo "served: $(awk '{print $4}' ~/q6_base.txt | sort | uniq -c | tr '\n' ' ')"

echo "===== STEP 1 EPP를 0으로, 진짜 다운 확인 ====="
$K -n $NS scale deploy/pd-disaggregation-epp --replicas=0 >/dev/null
for i in $(seq 1 60); do
  np=$($K -n $NS get pods -o name 2>/dev/null | grep -c pd-disaggregation-epp)
  ep=$($K -n $NS get endpoints pd-disaggregation-epp -o jsonpath='{.subsets}' 2>/dev/null)
  if timeout 2 bash -c "echo > /dev/tcp/$EPP_IP/9002" 2>/dev/null; then refused=no; else refused=yes; fi
  echo "  check $i: epp_pods=$np endpoints='${ep:-empty}' port9002_refused=$refused"
  [ "$np" = 0 ] && [ -z "$ep" ] && [ "$refused" = yes ] && { echo "  -> EPP 완전 다운 확인"; break; }
  sleep 3
done

echo "===== STEP 2 FailClose (EPP 다운) → 503 기대 ====="
mkrule FailClose; T2=$(date -u +%Y-%m-%dT%H:%M:%SZ); send_codes 20 fc ~/q6_fc.txt
echo "codes: $(awk '{print $2}' ~/q6_fc.txt | sort | uniq -c | tr '\n' ' ')"
echo "지연(초) min/max: $(awk '{print $3}' ~/q6_fc.txt | sort -n | sed -n '1p;$p' | tr '\n' ' ')"
echo "응답 본문 1개 샘플:"; curl -s -m5 -X POST http://$IP:$PORT/v1/completions -H 'Content-Type: application/json' -d "{\"model\":\"$MODEL\",\"prompt\":\"x\",\"max_tokens\":4}" | head -c 200; echo
echo "loxilb 로그(FailClose):"; $K -n kube-system logs ds/loxilb-lb --since-time=$T2 2>/dev/null | grep -iE 'epp_unavailable|answered 503' | tail -3

echo "===== STEP 3 FailOpen (같은 다운 상태) → 200, loxilb RR 분배 기대 ====="
mkrule FailOpen; T3=$(date -u +%Y-%m-%dT%H:%M:%SZ); send_attrib 20 fo ~/q6_fo.txt
echo "codes: $(awk '{print $2}' ~/q6_fo.txt | sort | uniq -c | tr '\n' ' ')"
echo "served 분포(loxilb 자체 분배): $(awk '{print $4}' ~/q6_fo.txt | sort | uniq -c | tr '\n' ' ')"
echo "loxilb 로그(FailOpen):"; $K -n kube-system logs ds/loxilb-lb --since-time=$T3 2>/dev/null | grep -iE "FailOpen - the rule's own selector" | tail -3

echo "===== STEP 4 복구 (EPP replicas=$REPL) ====="
$K -n $NS scale deploy/pd-disaggregation-epp --replicas=$REPL >/dev/null
$K -n $NS rollout status deploy/pd-disaggregation-epp --timeout=180s
for i in $(seq 1 40); do if timeout 2 bash -c "echo > /dev/tcp/$EPP_IP/9002" 2>/dev/null; then echo "  :9002 수락(EPP 복귀)"; break; fi; sleep 3; done
sleep 3
mkrule FailClose; T4=$(date -u +%Y-%m-%dT%H:%M:%SZ); send_attrib 8 rec ~/q6_rec.txt
echo "codes: $(awk '{print $2}' ~/q6_rec.txt | sort | uniq -c | tr '\n' ' ')"; echo "served: $(awk '{print $4}' ~/q6_rec.txt | sort | uniq -c | tr '\n' ' ')"
curl -s -X DELETE "$LB/netlox/v1/config/loadbalancer/externalipaddress/$IP/port/$PORT/protocol/tcp" >/dev/null
echo "P1=$P1 P2=$P2 P3=$P3"; echo "PHASE6B DONE"
