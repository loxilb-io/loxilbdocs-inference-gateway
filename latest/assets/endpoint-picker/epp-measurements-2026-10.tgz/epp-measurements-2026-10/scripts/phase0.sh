#!/bin/bash
export PATH=$HOME/bin:$PATH KUBECONFIG=$HOME/.kube/config
K="sudo -n /var/lib/rancher/rke2/bin/kubectl --kubeconfig /etc/rancher/rke2/rke2.yaml"
NS=llm-d-pd-disaggregation; LB=http://192.0.2.10:11111
B=~/verify-baseline; mkdir -p $B; cd $B
echo "### versions"; curl -s $LB/netlox/v1/version | tee version.json; echo
$K version -o json 2>/dev/null | python3 -c 'import sys,json;d=json.load(sys.stdin);print("k8s server",d.get("serverVersion",{}).get("gitVersion"))' | tee k8s-version.txt
echo "### CRDs (inference)"; $K get crd -o name 2>/dev/null | grep -iE "inference|gateway" | tee crds.txt
echo "### InferencePool"; $K get inferencepool -n $NS -o yaml > inferencepool.yaml 2>/dev/null; $K get inferencepool -n $NS 2>/dev/null | tee inferencepool.txt
$K explain inferencepool.spec 2>/dev/null | head -40 > inferencepool-explain.txt
echo "### EPP deploy + config"; $K get deploy -n $NS pd-disaggregation-epp -o yaml > epp-deploy.yaml 2>/dev/null
$K get deploy -n $NS pd-disaggregation-epp -o jsonpath='{.spec.template.spec.containers[?(@.name=="epp")].image}{"\n"}{.spec.template.spec.containers[?(@.name=="epp")].args}' | tee epp-args.txt; echo
$K get cm -n $NS pd-disaggregation-epp -o jsonpath='{.data.pd-config\.yaml}' > epp-pd-config.yaml 2>/dev/null; echo "--- epp plugins ---"; cat epp-pd-config.yaml
echo "### EPP --help (plugin list)"; $K exec -n $NS deploy/pd-disaggregation-epp -c epp -- /app/epp --help 2>/dev/null | head -60 > epp-help.txt || echo "(no --help)"
echo "### vLLM deploy + placement"; $K get deploy -n $NS pd-disaggregation-nvidia-gpu-vllm-aggregated -o yaml > vllm-deploy.yaml 2>/dev/null
$K get pods -n $NS -l llm-d.ai/role=aggregated -o wide --field-selector status.phase=Running 2>/dev/null | tee vllm-pods.txt
echo "### loxilb rules dump"; curl -s $LB/netlox/v1/config/loadbalancer/all > loxilb-rules.json; python3 -c 'import json;d=json.load(open("loxilb-rules.json"));[print(r["serviceArguments"]) for r in d.get("lbAttr",[])]' | tee loxilb-rules.txt
echo "### metric names"; curl -s $LB/netlox/v1/metrics | grep -E "^# TYPE loxilb_ai_epp|^# TYPE loxilb_pd_kv|^# TYPE loxilb_kv" | tee loxilb-epp-metric-names.txt
EPP_IP=$($K -n $NS get svc pd-disaggregation-epp -o jsonpath='{.spec.clusterIP}')
echo "EPP_IP=$EPP_IP" | tee epp-ip.txt
$K exec -n $NS deploy/pd-disaggregation-epp -c epp -- wget -qO- http://localhost:9090/metrics 2>/dev/null | grep -E "^# TYPE" | grep -iE "scheduler|request|endpoint|inference" | head -30 > epp-metric-names.txt 2>/dev/null || curl -s http://$EPP_IP:9090/metrics 2>/dev/null | grep "^# TYPE" | head -30 > epp-metric-names.txt
echo "### EPP current log level + a recent decision sample"; $K -n $NS logs deploy/pd-disaggregation-epp -c epp --tail=20 2>/dev/null | tail -8 > epp-log-sample.txt; cat epp-log-sample.txt | cut -c1-160
echo "PHASE0 DONE $(date -u +%T)"
