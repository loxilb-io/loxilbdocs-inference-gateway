#!/bin/bash
export PATH=$HOME/bin:$PATH KUBECONFIG=$HOME/.kube/config
K="sudo -n /var/lib/rancher/rke2/bin/kubectl --kubeconfig /etc/rancher/rke2/rke2.yaml"
NS=llm-d-pd-disaggregation; LB=http://192.0.2.10:11111; IP=192.0.2.10; PORT=8080; MODE=$1
EPP_IP=$($K -n $NS get svc pd-disaggregation-epp -o jsonpath='{.spec.clusterIP}')
mapfile -t PODIP < <($K -n $NS get pods -l llm-d.ai/role=aggregated --field-selector status.phase=Running -o jsonpath='{range .items[*]}{.status.podIP}{"\n"}{end}')
CS=$(IFS=,;echo "${PODIP[*]}")
EPS=""; for ip in "${PODIP[@]}"; do EPS="$EPS${EPS:+,}{\"endpointIP\":\"$ip\",\"targetPort\":8000,\"weight\":1}"; done
curl -s -X DELETE "$LB/netlox/v1/config/loadbalancer/externalipaddress/$IP/port/$PORT/protocol/tcp" >/dev/null
if [ "$MODE" = epp ]; then A="\"eppEndpoint\":\"$EPP_IP:9002\",\"eppFailureMode\":\"FailClose\",\"eppTimeoutMs\":3000,"; nm=vrfy-epp; else A=""; nm=vrfy-noepp; fi
curl -s -X POST $LB/netlox/v1/config/loadbalancer -H 'Content-Type: application/json' -d "{\"serviceArguments\":{\"externalIP\":\"$IP\",\"port\":$PORT,\"protocol\":\"tcp\",\"mode\":4,\"sel\":0,\"name\":\"$nm\",$A\"_\":0},\"endpoints\":[$EPS]}" >/dev/null 2>&1
# retry without trailing _ hack if failed
curl -s $LB/netlox/v1/config/loadbalancer/all | grep -q "\"port\": $PORT" || curl -s -X POST $LB/netlox/v1/config/loadbalancer -H 'Content-Type: application/json' -d "{\"serviceArguments\":{\"externalIP\":\"$IP\",\"port\":$PORT,\"protocol\":\"tcp\",\"mode\":4,\"sel\":0,\"name\":\"$nm\"$([ "$MODE" = epp ] && echo ",\"eppEndpoint\":\"$EPP_IP:9002\",\"eppFailureMode\":\"FailClose\",\"eppTimeoutMs\":3000")},\"endpoints\":[$EPS]}" >/dev/null
sleep 2
python3 ~/qa_p3b.py $IP $PORT 8 20 $MODE $CS > ~/p3b_$MODE.sent 2>/dev/null
echo "=== MODE=$MODE sent=$(wc -l < ~/p3b_$MODE.sent) codes:$(awk '{print $4}' ~/p3b_$MODE.sent|sort|uniq -c|tr '\n' ' ') ambig:$(grep -c AMBIG ~/p3b_$MODE.sent) none:$(grep -c NONE ~/p3b_$MODE.sent)"
python3 - "$MODE" <<'PY'
import sys,collections
mode=sys.argv[1]; bys=collections.defaultdict(list)
for l in open("$HOME/p3b_%s.sent"%mode):
    p=l.split()
    if len(p)<6: continue
    bys[int(p[1])].append((int(p[2]),p[5]))
rets=[]
for sid,seq in sorted(bys.items()):
    seq.sort(); pods=[p for _,p in seq if not p.startswith(("AMBIG","NONE"))]
    if not pods: continue
    dom=collections.Counter(pods).most_common(1)[0]; r=100.0*dom[1]/len(pods); rets.append(r)
    print("  session %d: %d turns dom %s x%d = %.0f%%  seq=%s"%(sid,len(pods),dom[0][-6:],dom[1],r,"".join(p[-1] for p in pods)))
print("  MEAN per-session retention: %.1f%%"%(sum(rets)/len(rets)) if rets else "  no data")
PY
echo "P3B $MODE DONE $(date -u +%T)"
