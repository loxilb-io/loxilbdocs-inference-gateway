#!/bin/bash
# A) 무거운 캐시 재사용 벤치 (발표/검증 규모) — kvbench 확대판
# 40세션, 동시성 16, long 15턴 + short 6턴. cold/warm 분리 유지.
set -u
K="sudo -n /var/lib/rancher/rke2/bin/kubectl --kubeconfig /etc/rancher/rke2/rke2.yaml"
NS=llm-d-pd-disaggregation
VIP=192.0.2.11; API=http://$VIP:11111/netlox/v1; PORT=${PORT:-8088}
MODEL=Qwen/Qwen3-32B-FP8; SESS=${SESS:-40}; CONC=${CONC:-16}; MAXTOK=${MAXTOK:-32}
RUNID=$(date +%s)   # tag에 넣어 실행마다 프리픽스를 새로 → 진짜 cold 시작 (재실행 캐리오버 방지)
OUT=${OUT:-$HOME/cache_bench_heavy_$(date +%Y%m%dT%H%M%S)}; mkdir -p "$OUT"
echo "결과 디렉토리: $OUT  (SESS=$SESS CONC=$CONC RUNID=$RUNID)"

mapfile -t IPS < <($K -n $NS get pods -l llm-d.ai/role=aggregated -o json 2>/dev/null | python3 -c '
import sys,json
for p in json.load(sys.stdin)["items"]:
    cs=p["status"].get("containerStatuses",[])
    if p["status"]["phase"]=="Running" and cs and all(c.get("ready") for c in cs):
        print(p["status"]["podIP"])')
echo "READY 파드: ${IPS[*]:-none} (${#IPS[@]}개)"
[ ${#IPS[@]} -lt 2 ] && { echo "Ready 파드 부족 → 중단"; exit 1; }
EPP_IP=$($K -n $NS get svc pd-disaggregation-epp -o jsonpath='{.spec.clusterIP}'); echo "EPP ClusterIP=$EPP_IP"
EPS=""; for ip in "${IPS[@]}"; do EPS="$EPS${EPS:+,}{\"endpointIP\":\"$ip\",\"targetPort\":8000,\"weight\":1}"; done

metric_sum(){ curl -s -m5 http://$1:8000/metrics 2>/dev/null | awk -v k="$2" '$0 ~ "^"k"[ {]"{s+=$NF}END{print s+0}'; }
snap(){ local tag=$1; local f=$OUT/snap_$tag.txt; : > $f; for ip in "${IPS[@]}"; do
    echo "$ip $(metric_sum $ip vllm:prefix_cache_queries_total) $(metric_sum $ip vllm:prefix_cache_hits_total)" >> $f; done; }
mkrule(){ local mode=$1 sel epp name
  case $mode in
    epp)   sel=0; name=cache-epp;   epp=",\"eppEndpoint\":\"$EPP_IP:9002\",\"eppFailureMode\":\"FailClose\",\"eppTimeoutMs\":5000";;
    chwbl) sel=8; name=cache-chwbl; epp="";;
    rr)    sel=0; name=cache-rr;    epp="";;
  esac
  curl -s -X DELETE "$API/config/loadbalancer/externalipaddress/$VIP/port/$PORT/protocol/tcp" >/dev/null
  curl -s -X POST $API/config/loadbalancer -H 'Content-Type: application/json' \
    -d "{\"serviceArguments\":{\"externalIP\":\"$VIP\",\"port\":$PORT,\"protocol\":\"tcp\",\"mode\":4,\"sel\":$sel,\"name\":\"$name\"$epp},\"endpoints\":[$EPS]}" >/dev/null
  sleep 2; }

SUMMARY=$OUT/summary.tsv
echo -e "scenario\tmode\tcache_reuse\tqueries\tttft_cold_p50\tttft_warm_p50\tttft_warm_p95\te2e_warm_p50\treqs\terrs" > $SUMMARY

run_scn(){ local scn=$1 turns=$2 words=$3
  echo "========== 시나리오 $scn (turns=$turns words=$words, SESS=$SESS CONC=$CONC) =========="
  for mode in epp chwbl rr; do
    echo "----- $scn / $mode  $(date +%H:%M:%S) -----"
    mkrule $mode
    snap "${scn}_${mode}_before"
    python3 ~/kvbench.py --host $VIP --port $PORT --model $MODEL --tag "${mode}-${scn}-${RUNID}" \
      --sessions $SESS --turns $turns --words $words --concurrency $CONC --max-tokens $MAXTOK \
      --out $OUT/cb_${mode}_${scn}.jsonl > $OUT/cb_${mode}_${scn}.out 2>&1
    snap "${scn}_${mode}_after"
    python3 - "$OUT/snap_${scn}_${mode}_before.txt" "$OUT/snap_${scn}_${mode}_after.txt" "$OUT/cb_${mode}_${scn}.out" "$scn" "$mode" >> $SUMMARY <<'PY'
import sys,re
bf,af,out,scn,mode=sys.argv[1:6]
def load(f):
    q=h=0
    for l in open(f):
        _,qq,hh=l.split(); q+=int(float(qq)); h+=int(float(hh))
    return q,h
q0,h0=load(bf); q1,h1=load(af); dq=q1-q0; dh=h1-h0
reuse="%.1f%%"%(100*dh/dq) if dq else "n/a"
txt=open(out,encoding="utf-8",errors="replace").read()
def warm(line):
    m=re.search(line+r".*?p50=\s*([\d.]+)ms.*?p95=\s*([\d.]+)ms",txt); return (m.group(1),m.group(2)) if m else ("?","?")
cc=re.search(r"cold TTFT.*?p50=\s*([\d.]+)ms",txt); cold=cc.group(1) if cc else "?"
wp,w95=warm(r"warm TTFT")
ec=re.search(r"warm E2E.*?p50=\s*([\d.]+)ms",txt); e2e=ec.group(1) if ec else "?"
rq=re.search(r"requests=(\d+) errors=(\d+)",txt); reqs,errs=(rq.group(1),rq.group(2)) if rq else ("?","?")
print("\t".join([scn,mode,reuse,str(dq),cold,wp,w95,e2e,reqs,errs]))
PY
    echo "   $(tail -1 $SUMMARY)"
  done; }

run_scn long 15 4500
run_scn short 6 150

curl -s -X DELETE "$API/config/loadbalancer/externalipaddress/$VIP/port/$PORT/protocol/tcp" >/dev/null
echo; echo "========== 요약 (A/heavy) =========="; column -t -s$'\t' $SUMMARY
echo "CACHE_BENCH_HEAVY DONE -> $OUT"
