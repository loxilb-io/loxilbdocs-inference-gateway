#!/bin/bash
# B) 표준 서빙 벤치 (guidellm 0.8.1) — 공유 프리픽스 부하로 모드별 throughput/TTFT/latency + vLLM 캐시 재사용률.
# A(kvbench)와 같은 파드/VIP를 쓰므로 A가 끝난 뒤 단독 실행할 것.
set -u
export PATH=$HOME/.local/bin:$PATH
K="sudo -n /var/lib/rancher/rke2/bin/kubectl --kubeconfig /etc/rancher/rke2/rke2.yaml"
NS=llm-d-pd-disaggregation
VIP=192.0.2.11; API=http://$VIP:11111/netlox/v1; PORT=${PORT:-8088}
MODEL=Qwen/Qwen3-32B-FP8; STREAMS=${STREAMS:-16}; COUNT=${COUNT:-300}
OUT=${OUT:-$HOME/guidellm_bench_$(date +%Y%m%dT%H%M%S)}; mkdir -p "$OUT"
echo "결과 디렉토리: $OUT (STREAMS=$STREAMS COUNT=$COUNT)"

mapfile -t IPS < <($K -n $NS get pods -l llm-d.ai/role=aggregated -o json 2>/dev/null | python3 -c '
import sys,json
for p in json.load(sys.stdin)["items"]:
    cs=p["status"].get("containerStatuses",[])
    if p["status"]["phase"]=="Running" and cs and all(c.get("ready") for c in cs):
        print(p["status"]["podIP"])')
echo "READY 파드: ${IPS[*]:-none} (${#IPS[@]}개)"
[ ${#IPS[@]} -lt 2 ] && { echo "Ready 파드 부족 → 중단"; exit 1; }
EPP_IP=$($K -n $NS get svc pd-disaggregation-epp -o jsonpath='{.spec.clusterIP}'); echo "EPP ClusterIP=$EPP_IP"
EPS=""; for ip in "${IPS[@]}"; do EPS="$EPS${EPS:+,}{\"endpointIP\":\"$ip\",\"targetPort\":8000,\"weight\":1}"; done

metric_sum(){ curl -s -m5 http://$1:8000/metrics 2>/dev/null | awk -v k="$2" '$0 ~ "^"k"[ {]"{s+=$NF}END{print s+0}'; }
snap(){ local tag=$1; local f=$OUT/snap_$tag.txt; : > $f; for ip in "${IPS[@]}"; do
    echo "$ip $(metric_sum $ip vllm:prefix_cache_queries_total) $(metric_sum $ip vllm:prefix_cache_hits_total)" >> $f; done; }
mkrule(){ local mode=$1 sel epp name
  case $mode in
    epp)   sel=0; name=cache-epp;   epp=",\"eppEndpoint\":\"$EPP_IP:9002\",\"eppFailureMode\":\"FailClose\",\"eppTimeoutMs\":5000";;
    chwbl) sel=8; name=cache-chwbl; epp="";;
    rr)    sel=0; name=cache-rr;    epp="";;
  esac
  curl -s -X DELETE "$API/config/loadbalancer/externalipaddress/$VIP/port/$PORT/protocol/tcp" >/dev/null
  curl -s -X POST $API/config/loadbalancer -H 'Content-Type: application/json' \
    -d "{\"serviceArguments\":{\"externalIP\":\"$VIP\",\"port\":$PORT,\"protocol\":\"tcp\",\"mode\":4,\"sel\":$sel,\"name\":\"$name\"$epp},\"endpoints\":[$EPS]}" >/dev/null
  sleep 2; }

SUMMARY=$OUT/summary.tsv
echo -e "scenario\tmode\tcache_reuse\treq_s\ttok_s\tttft_p50\tttft_p95\tlat_p50\tok\terr" > $SUMMARY

run_scn(){ local scn=$1 ptok=$2 otok=$3 xtok=$4
  echo "========== 시나리오 $scn (prompt=$ptok out=$otok prefix=$xtok) =========="
  for mode in epp chwbl rr; do
    echo "----- $scn / $mode  $(date +%H:%M:%S) -----"
    mkrule $mode
    snap "${scn}_${mode}_before"
    guidellm run \
      --backend kind=openai_http,target=http://$VIP:$PORT,model=$MODEL \
      --data kind=synthetic_text,prompt_tokens=$ptok,output_tokens=$otok,prefix_tokens=$xtok \
      --profile kind=concurrent --override profile.streams $STREAMS \
      --constraint kind=max_requests,count=$COUNT \
      --tokenizer kind=hf_auto,model=gpt2 \
      --output kind=json,path=$OUT/g_${mode}_${scn}.json \
      --disable-progress > $OUT/g_${mode}_${scn}.out 2>&1
    snap "${scn}_${mode}_after"
    python3 - "$OUT/snap_${scn}_${mode}_before.txt" "$OUT/snap_${scn}_${mode}_after.txt" "$OUT/g_${mode}_${scn}.json" "$scn" "$mode" >> $SUMMARY <<'PY'
import sys,json
bf,af,js,scn,mode=sys.argv[1:6]
def load(f):
    q=h=0
    for l in open(f):
        _,qq,hh=l.split(); q+=int(float(qq)); h+=int(float(hh))
    return q,h
q0,h0=load(bf); q1,h1=load(af); dq=q1-q0; dh=h1-h0
reuse="%.1f%%"%(100*dh/dq) if dq else "n/a"
def g(d,*ks):
    for k in ks:
        if isinstance(d,dict) and k in d: d=d[k]
        else: return None
    return d
try:
    d=json.load(open(js)); m=d["benchmarks"][0]["metrics"]
    reqs=g(m,"requests_per_second","successful","mean")
    toks=g(m,"output_tokens_per_second","successful","mean")
    ttp50=g(m,"time_to_first_token_ms","successful","percentiles","p50")
    ttp95=g(m,"time_to_first_token_ms","successful","percentiles","p95")
    latp50=g(m,"request_latency","successful","percentiles","p50")
    ok=g(m,"request_totals","successful"); err=g(m,"request_totals","errored")
    f=lambda x,s=1: ("%.1f"%(x*s)) if isinstance(x,(int,float)) else "?"
    row=[scn,mode,reuse,f(reqs),f(toks),f(ttp50),f(ttp95),f(latp50,1000),str(ok),str(err)]
except Exception as e:
    row=[scn,mode,reuse,"ERR","","","","",str(e)[:30],""]
print("\t".join(row))
PY
    echo "   $(tail -1 $SUMMARY)"
  done; }

run_scn long 2048 32 1920
run_scn short 256 16 160

curl -s -X DELETE "$API/config/loadbalancer/externalipaddress/$VIP/port/$PORT/protocol/tcp" >/dev/null
echo; echo "========== 요약 (B/guidellm, lat_p50=ms) =========="; column -t -s$'\t' $SUMMARY
echo "GUIDELLM_BENCH DONE -> $OUT"
