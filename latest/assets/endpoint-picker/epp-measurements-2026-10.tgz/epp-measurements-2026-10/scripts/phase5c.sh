#!/bin/bash
export PATH=$HOME/bin:$PATH KUBECONFIG=$HOME/.kube/config
K="sudo -n /var/lib/rancher/rke2/bin/kubectl --kubeconfig /etc/rancher/rke2/rke2.yaml"
NS=llm-d-pd-disaggregation; IP=192.0.2.10; MODEL=Qwen/Qwen3-32B-FP8; PORT=8080
# pick a READY victim (not the warming one)
VN=$($K -n $NS get pods -l llm-d.ai/role=aggregated -o json | python3 -c 'import sys,json;[print(p["metadata"]["name"],p["status"]["podIP"]) for p in json.load(sys.stdin)["items"] if all(c.get("ready") for c in p["status"].get("containerStatuses",[])) and p["status"]["phase"]=="Running"]' | head -1)
NAME=${VN% *}; VIP=${VN#* }
echo "victim(ready): $NAME ($VIP)"
echo "=== vLLM processes in container"; $K -n $NS exec $NAME -c vllm -- ps -eo pid,ppid,comm,args --no-headers 2>/dev/null | grep -iE "vllm|python|EngineCore|api_server" | head -8 | cut -c1-120
# find the main api server pid (PID 1 is the entrypoint)
MAINPID=$($K -n $NS exec $NAME -c vllm -- sh -c 'cat /proc/1/cmdline | tr "\0" " "' 2>/dev/null)
echo "PID1 cmdline: $(echo $MAINPID | cut -c1-100)"
ms(){ date +%s%3N; }
echo ">>> $(ms) health BEFORE stop: $(curl -s -m3 -o /dev/null -w '%{http_code}' http://$VIP:8000/health)"
echo ">>> $(ms) SIGSTOP all python/vllm procs in container"
$K -n $NS exec $NAME -c vllm -- bash -c 'for p in $(pgrep -f "vllm|api_server|EngineCore|python"); do kill -STOP $p 2>/dev/null; done' 2>/dev/null
sleep 2
echo ">>> $(ms) health AFTER stop (expect timeout/fail): $(curl -s -m3 -o /dev/null -w '%{http_code}' http://$VIP:8000/health || echo TIMEOUT)"
scnt0=$(curl -s -m5 http://$VIP:8000/metrics 2>/dev/null | awk '/^vllm:request_success_total/{s+=$NF}END{print s+0}')
echo ">>> $(ms) victim succ counter at stop: $scnt0"
# load for 20s, record code+time, and whether loxilb routed to victim
LOG=~/p5c.log; : > $LOG; START=$(date -u +%Y-%m-%dT%H:%M:%SZ)
t_end=$(( $(date +%s) + 20 ))
while [ $(date +%s) -lt $t_end ]; do t=$(ms); r=$(curl -s -o /dev/null -m 20 -w '%{http_code} %{time_total}' -X POST http://$IP:$PORT/v1/completions -H 'Content-Type: application/json' -d "{\"model\":\"$MODEL\",\"prompt\":\"5c $t uniq$RANDOM\",\"max_tokens\":8}"); echo "$t $r" >> $LOG; done
echo ">>> $(ms) SIGCONT"; $K -n $NS exec $NAME -c vllm -- bash -c 'for p in $(pgrep -f "vllm|api_server|EngineCore|python"); do kill -CONT $p 2>/dev/null; done' 2>/dev/null
scnt1=$(curl -s -m5 http://$VIP:8000/metrics 2>/dev/null | awk '/^vllm:request_success_total/{s+=$NF}END{print s+0}')
echo "### during STOP: victim succ $scnt0 -> $scnt1 (served +$((scnt1-scnt0)) during stop; 0 = truly hung)"
echo "### load during STOP: reqs=$(wc -l < $LOG) codes:$(awk '{print $2}' $LOG|sort|uniq -c|tr '\n' ' ') maxtime=$(awk '{if($3>m)m=$3}END{print m}' $LOG)s  slow>2s=$(awk '$3>2' $LOG|wc -l)"
echo "### loxilb routing to victim $VIP during STOP:"; $K -n kube-system logs ds/loxilb-lb --since-time=$START 2>/dev/null | grep -oE "\-> 10\.42\.[0-9.]+" | sort | uniq -c
echo "### slow/err detail:"; awk '$2!=200 || $3>2 {print}' $LOG | head -15
echo "PHASE5C DONE"
