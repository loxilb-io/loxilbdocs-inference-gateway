import sys,time,json,http.client,random
host,port,S,T,tagbase,salt=sys.argv[1],int(sys.argv[2]),int(sys.argv[3]),int(sys.argv[4]),sys.argv[5],sys.argv[6]
MODEL="Qwen/Qwen3-32B-FP8"
TOPICS=["Roman aqueducts","deep-sea life","medieval guilds","jet engines","Andean farming","quantum codes","Baroque music","coral reefs"]
def preamble(i):
    t=TOPICS[i%len(TOPICS)]
    # salt+tagbase make every mode's prefixes unique -> fair cold start per mode
    head="Run %s/%s. You are an expert tutor on %s (session %d). Keep a coherent, growing thread.\n\n"%(tagbase,salt,t,i)
    pad=" ".join("Regarding %s (%s-%d-f%d), a careful concrete explanation with worked examples helps the learner."%(t,salt,i,j) for j in range(120))
    return head+pad+"\n\n"
sess=[{"id":i,"pre":preamble(i),"hist":[]} for i in range(S)]
QS=["Overview?","A common misconception?","Core mechanism step by step?","Compare to a related idea.","A concrete example?","Why did it develop this way?","Main trade-offs?","Walk through a worked case.","What would an expert add?","Summarize so far."]
def send(s,k):
    q=QS[k%len(QS)];p=s["pre"]
    for u,a in s["hist"]: p+="Q: "+u+"\nA: "+a+"\n"
    p+="Q: "+q+"\nA:"
    body=json.dumps({"model":MODEL,"prompt":p,"max_tokens":40,"temperature":0,"stream":True})
    txt=[];code=0
    try:
        c=http.client.HTTPConnection(host,port,timeout=90)
        c.request("POST","/v1/completions",body=body,headers={"Content-Type":"application/json","x-request-id":"%s-s%02d-t%02d"%(tagbase,s["id"],k)})
        r=c.getresponse();code=r.status;buf=b""
        if code==200:
            while True:
                ch=r.read1(65536) if hasattr(r,"read1") else r.read(4096)
                if not ch:break
                buf+=ch
                while b"\n" in buf:
                    ln,buf=buf.split(b"\n",1);ln=ln.strip()
                    if ln.startswith(b"data:"):
                        d=ln[5:].strip()
                        if d==b"[DONE]":break
                        try:
                            for cc in json.loads(d).get("choices",[]):
                                if cc.get("text"):txt.append(cc["text"])
                        except:pass
        else:r.read()
        c.close()
    except:code=-1
    s["hist"].append((q,"".join(txt).strip() or "(ok)"))
    print("%s-s%02d-t%02d %d"%(tagbase,s["id"],k,code))
for k in range(T):
    o=list(range(S));random.shuffle(o)
    for sid in o: send(sess[sid],k)
