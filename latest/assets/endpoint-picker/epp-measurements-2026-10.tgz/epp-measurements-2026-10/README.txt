Raw material behind the Endpoint Picker measurements (October 2026).

results/   per-phase logs, request lists, guidellm JSON and summary .tsv/.txt files
scripts/   the one-off scripts that produced them, including the multi-turn client kvbench.py,
           the harness's earlier affinity check q2_affinity.sh, and the guidellm drivers.
           Addresses and node names were rewritten one-to-one to documentation ranges;
           several scripts expect the RKE2 kubectl path and the lab's resource names.
