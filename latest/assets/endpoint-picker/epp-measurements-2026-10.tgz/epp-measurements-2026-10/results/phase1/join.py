#!/usr/bin/env python3
# Q1 요청별 1:1 조인: 같은 x-request-id 의 EPP endpoint 와 loxilb '-> ip' 비교
import json,re
epp={}
for l in open("epp_handled.log"):
    try:d=json.loads(l)
    except:continue
    if d.get("x-request-id") and d.get("endpoint"): epp[d["x-request-id"]]=d["endpoint"].split(":")[0]
lox=[m.group(2) for m in (re.search(r'sid=(\d+).*-> ([0-9.]+):',l) for l in open("loxilb_epp.log")) if m]
sent=[x.split()[0] for x in open("sent.txt") if x.strip()]
eip=[epp[r] for r in sent if r in epp]
n=min(len(eip),len(lox)); match=sum(eip[i]==lox[i] for i in range(n))
print("요청수=%d  EPP결정=%d  loxilb목적지=%d  일치=%d/%d (%.1f%%)"%(len(sent),len(epp),len(lox),match,n,100*match/n))
